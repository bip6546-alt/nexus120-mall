import { Room, Client } from "colyseus";

type Avatar = {
  id: string;
  name: string;
  floor: number;
  x: number;
  y: number;
  z: number;
  rot: number;
  state: "walking" | "idle" | "elevator" | "escalator";
};

type MallState = {
  users: Map<string, Avatar>;
  floor: number;
  capacity: number;
};

export class MallRoom extends Room<MallState> {
  maxClients = Number(process.env.ROOM_CAPACITY || 80);

  onCreate(options: { floor?: number }) {
    this.setState({
      users: new Map(),
      floor: Math.max(1, Math.min(120, Number(options?.floor || 1))),
      capacity: this.maxClients
    });

    this.onMessage("move", (client, msg) => {
      const a = this.state.users.get(client.sessionId);
      if (!a || !Number.isFinite(msg?.x) || !Number.isFinite(msg?.z)) return;

      // Authoritative server clamps movement to safe values.
      const dx = Math.max(-1.5, Math.min(1.5, Number(msg.x) - a.x));
      const dz = Math.max(-1.5, Math.min(1.5, Number(msg.z) - a.z));
      a.x += dx;
      a.z += dz;
      a.rot = Number.isFinite(msg.rot) ? Number(msg.rot) : a.rot;
      a.state = msg.mode === "elevator" || msg.mode === "escalator" ? msg.mode : "walking";
    });

    this.onMessage("floor", (client, msg) => {
      const a = this.state.users.get(client.sessionId);
      if (!a) return;
      const floor = Math.max(1, Math.min(120, Number(msg?.floor || a.floor)));
      a.floor = floor;
      a.state = "elevator";
      this.broadcast("floorChanged", { id: client.sessionId, floor });
    });
  }

  onJoin(client: Client, options: { name?: string }) {
    const name = String(options?.name || "Guest").slice(0, 24);
    this.state.users.set(client.sessionId, {
      id: client.sessionId, name, floor: this.state.floor,
      x: 0, y: 0, z: 6, rot: 0, state: "idle"
    });
  }

  onLeave(client: Client) {
    this.state.users.delete(client.sessionId);
  }
}
