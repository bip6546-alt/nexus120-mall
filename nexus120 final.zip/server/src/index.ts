import "dotenv/config";
import express from "express";
import cors from "cors";
import { createServer } from "http";
import { Server } from "colyseus";
import { RedisPresence } from "@colyseus/redis-presence";
import { RedisDriver } from "@colyseus/redis-driver";
import { MallRoom } from "./rooms/MallRoom.js";
import { attachWebRTC } from "./webrtc.js";

const app = express();
app.use(cors({ origin: process.env.CLIENT_ORIGIN?.split(",") || true }));
app.get("/health", (_req, res) => res.json({ ok: true, service: "nexus120-realtime" }));

const httpServer = createServer(app);
const gameServer = new Server({
  server: httpServer,
  presence: new RedisPresence(process.env.REDIS_URL || "redis://127.0.0.1:6379"),
  driver: new RedisDriver(process.env.REDIS_URL || "redis://127.0.0.1:6379")
});

gameServer.define("mall", MallRoom).filterBy(["floor"]);

attachWebRTC(httpServer);

const port = Number(process.env.PORT || 2567);
httpServer.listen(port, () => console.log(`NEXUS realtime + WebRTC signaling server listening on :${port}`));
