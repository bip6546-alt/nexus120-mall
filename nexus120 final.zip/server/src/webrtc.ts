import { createHmac, timingSafeEqual } from 'node:crypto';
import type { Server as HttpServer } from 'node:http';
import { WebSocketServer, WebSocket } from 'ws';

type Peer = { id: string; role: 'admin' | 'customer'; ws: WebSocket; userId: number; name: string; floor: number; x: number; z: number; voiceEnabled: boolean; groupId: string | null };
type Group = { id: string; name: string; ownerId: string; members: Set<string> };
type TokenPayload = { uid: number; role: 'admin' | 'customer'; name: string; exp: number };

function secret() { return process.env.WEBRTC_SECRET || 'nexus120-dev-webrtc-secret-change-me'; }
function decodeToken(token: string): TokenPayload | null {
  try {
    const [raw, sig] = token.split('.'); if (!raw || !sig) return null;
    const expected = createHmac('sha256', secret()).update(raw).digest('base64url');
    if (sig.length !== expected.length || !timingSafeEqual(Buffer.from(sig), Buffer.from(expected))) return null;
    const payload = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8')) as TokenPayload;
    if (payload.uid < 0 || !payload.role || payload.exp < Math.floor(Date.now() / 1000)) return null;
    return payload;
  } catch { return null; }
}
function send(ws: WebSocket, message: unknown) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(message)); }
function distance(a: Peer, b: Peer) { return a.floor === b.floor ? Math.hypot(a.x - b.x, a.z - b.z) : Infinity; }
const PROXIMITY_METERS = Number(process.env.PROXIMITY_METERS || 0.10);

export function attachWebRTC(httpServer: HttpServer) {
  const wss = new WebSocketServer({ noServer: true });
  const peers = new Map<string, Peer>();
  const groups = new Map<string, Group>();
  let seq = 0; let groupSeq = 0;
  const MAX_GROUP_SIZE = 8;

  function nearby(peer: Peer) {
    return Array.from(peers.values()).filter(p => p.id !== peer.id && p.role === 'customer' && distance(peer, p) <= PROXIMITY_METERS);
  }
  function notifyProximity(peer: Peer) {
    const list = nearby(peer).map(p => ({ id: p.id, name: p.name, distance: Number(distance(peer, p).toFixed(3)), voiceEnabled: p.voiceEnabled }));
    send(peer.ws, { type: 'proximity-list', peers: list, radius: PROXIMITY_METERS });
  }
  function refreshAllProximity() {
    for (const p of peers.values()) if (p.role === 'customer') notifyProximity(p);
  }
  function canTalk(a: Peer, b: Peer) { return a.role === 'customer' && b.role === 'customer' && distance(a, b) <= PROXIMITY_METERS; }
  function groupFor(id: string) { for (const g of groups.values()) if (g.members.has(id)) return g; return undefined; }
  function groupState(g: Group) { return { id:g.id, name:g.name, ownerId:g.ownerId, members:Array.from(g.members).map(id=>{const p=peers.get(id);return p?{id:p.id,name:p.name,floor:p.floor,x:p.x,z:p.z,voiceEnabled:p.voiceEnabled}:null}).filter(Boolean) }; }
  function broadcastGroup(g: Group, msg: unknown) { for(const id of g.members){const p=peers.get(id);if(p)send(p.ws,msg);} }
  function broadcastGroupState(g: Group) { broadcastGroup(g,{type:'group-state',group:groupState(g)}); }
  function removeFromGroup(peer: Peer) { const g=peer.groupId?groups.get(peer.groupId):undefined; peer.groupId=null; if(!g)return; g.members.delete(peer.id); if(!g.members.size){groups.delete(g.id);return;} if(g.ownerId===peer.id)g.ownerId=Array.from(g.members)[0]; broadcastGroupState(g); }
  function inviteNearby(g: Group, peer: Peer) { for(const target of nearby(peer)){if(target.groupId||g.members.size>=MAX_GROUP_SIZE)continue;send(target.ws,{type:'group-invite',groupId:g.id,groupName:g.name,from:peer.id,fromName:peer.name});} }


  httpServer.on('upgrade', (req, socket, head) => {
    try {
      const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
      if (url.pathname !== '/ws') return;
      const payload = decodeToken(url.searchParams.get('token') || '');
      if (!payload) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); socket.destroy(); return; }
      wss.handleUpgrade(req, socket, head, ws => wss.emit('connection', ws, payload));
    } catch { socket.destroy(); }
  });

  wss.on('connection', (ws: WebSocket, payload: TokenPayload) => {
    const id = `${payload.role}-${++seq}-${Math.random().toString(36).slice(2, 8)}`;
    const peer: Peer = { id, role: payload.role, ws, userId: payload.uid, name: payload.name || payload.role, floor: 1, x: 0, z: 0, voiceEnabled: false, groupId: null };
    peers.set(id, peer);
    send(ws, { type: 'ready', peerId: id, role: peer.role, listeners: Array.from(peers.values()).filter(p => p.role === 'customer').length, proximityMeters: PROXIMITY_METERS });

    if (peer.role === 'customer') {
      refreshAllProximity();
      for (const p of peers.values()) if (p.role === 'admin') send(p.ws, { type: 'peer-join', peerId: id, name: peer.name });
    } else {
      for (const p of peers.values()) if (p.role === 'customer') send(ws, { type: 'peer-join', peerId: p.id, name: p.name });
      for (const p of peers.values()) if (p.role === 'customer') send(p.ws, { type: 'live-available', adminName: peer.name });
    }

    ws.on('message', raw => {
      try {
        const msg = JSON.parse(raw.toString());
        const to = typeof msg.to === 'string' ? peers.get(msg.to) : undefined;
        if (msg.type === 'start-live' && peer.role === 'admin') { for (const p of peers.values()) if (p.role === 'customer') send(p.ws, { type: 'live-start', adminName: peer.name }); return; }
        if (msg.type === 'stop-live' && peer.role === 'admin') { for (const p of peers.values()) if (p.role === 'customer') send(p.ws, { type: 'live-stop' }); return; }
        if ((msg.type === 'offer' || msg.type === 'answer' || msg.type === 'ice') && to) { send(to.ws, { ...msg, from: peer.id }); return; }
        if (msg.type === 'stats' && peer.role === 'admin') { send(ws, { type: 'stats', listeners: Array.from(peers.values()).filter(p => p.role === 'customer').length, admins: Array.from(peers.values()).filter(p => p.role === 'admin').length }); return; }

        if (msg.type === 'group-create' && peer.role === 'customer') {
          removeFromGroup(peer.id);
          const name=String(msg.name||'Shopping Group').trim().slice(0,40)||'Shopping Group';
          const g={id:`group-${++groupSeq}-${Math.random().toString(36).slice(2,6)}`,name,ownerId:peer.id,members:new Set<string>([peer.id])};
          groups.set(g.id,g); peer.groupId=g.id; broadcastGroupState(g); return;
        }
        if (msg.type === 'group-invite-nearby' && peer.role === 'customer') {
          const g=groupFor(peer.id); if(!g || g.members.size>=MAX_GROUP_SIZE)return;
          inviteNearby(g,peer); return;
        }
        if (msg.type === 'group-join' && peer.role === 'customer') {
          const g=groups.get(String(msg.groupId||'')); if(!g || g.members.size>=MAX_GROUP_SIZE || groupFor(peer.id))return;
          const leader=peers.get(g.ownerId); if(!leader || distance(peer,leader)>PROXIMITY_METERS)return;
          g.members.add(peer.id); peer.groupId=g.id; broadcastGroupState(g); return;
        }
        if (msg.type === 'group-leave' && peer.role === 'customer') { removeFromGroup(peer.id); return; }
        if (msg.type === 'group-chat' && peer.role === 'customer') {
          const g=groupFor(peer.id); if(!g)return; const text=String(msg.text||'').trim().slice(0,500); if(!text)return;
          for(const id of g.members){const p=peers.get(id);if(p)send(p.ws,{type:'group-chat',from:peer.name,name:peer.name,text,at:Date.now()});} return;
        }
        if (msg.type === 'group-voice' && peer.role === 'customer') { const g=groupFor(peer.id); if(!g)return; for(const id of g.members){ if(id!==peer.id){const p=peers.get(id); if(p)send(p.ws,{type:'voice-peer',peerId:peer.id,name:peer.name,enabled:!!msg.enabled,group:true});}} return; }

        if (msg.type === 'chat' && peer.role === 'customer' && to && canTalk(peer, to)) {
          const text = String(msg.text || '').trim().slice(0, 500); if (!text) return;
          send(to.ws, { type: 'chat', from: peer.id, name: peer.name, text, distance: Number(distance(peer, to).toFixed(3)), at: Date.now() });
          send(peer.ws, { type: 'chat-sent', to: to.id, name: to.name, text, distance: Number(distance(peer, to).toFixed(3)), at: Date.now() });
          return;
        }
      } catch { /* ignore malformed signaling packets */ }
    });

    ws.on('close', () => {
      if(peer.groupId) removeFromGroup(peer);
      peers.delete(id);
      if (peer.role === 'admin') for (const p of peers.values()) if (p.role === 'customer') send(p.ws, { type: 'live-stop' });
      if (peer.role === 'customer') {
        for (const p of peers.values()) if (p.role === 'customer') send(p.ws, { type: 'voice-peer', peerId: id, enabled: false });
        for (const p of peers.values()) if (p.role === 'admin') send(p.ws, { type: 'peer-leave', peerId: id });
        refreshAllProximity();
      }
    });
  });
  return wss;
}
