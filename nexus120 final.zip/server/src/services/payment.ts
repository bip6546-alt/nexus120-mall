export interface PaymentProvider {
  createCheckout(input: { userId:number; orderId:number; amount:number; currency:string }): Promise<{ checkoutUrl:string }>;
}

export class DemoPaymentProvider implements PaymentProvider {
  async createCheckout(input:{userId:number;orderId:number;amount:number;currency:string}) {
    return {
      checkoutUrl: `/checkout/demo?order=${input.orderId}`
    };
  }
}

/*
 Production:
 - Implement Stripe/Adyen/etc. using their official SDK.
 - Create hosted Checkout/PaymentIntent server-side.
 - Verify webhook signatures.
 - Mark orders paid only after verified provider events.
 - Never store PAN/CVC.
*/
