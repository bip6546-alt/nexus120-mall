import { Router } from "express";
export const merchantRouter = Router();

/*
  Production flow:
  1. Authenticate merchant against PHP session/JWT.
  2. Validate body with a schema library.
  3. Save storefront JSON to MySQL.
  4. Store GLB/media in object storage.
  5. Publish `storeUpdated` event through Redis.
*/
merchantRouter.get("/stores/:id/layout", async (req, res) => {
  res.json({
    storeId: Number(req.params.id),
    layout: {
      theme: "neon",
      sign: "NOVA",
      shelves: [],
      products: [],
      cameraStart: { x: 0, y: 1.7, z: 8 }
    }
  });
});

merchantRouter.post("/stores/:id/layout", async (req, res) => {
  res.status(501).json({
    ok:false,
    message:"Connect this route to the PHP/MySQL merchant API before production use."
  });
});
