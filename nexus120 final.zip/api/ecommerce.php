<?php
require_once __DIR__.'/../db.php';
require_once __DIR__.'/../integrations/connector.php';
header('Content-Type: application/json; charset=utf-8');
function out($x,$code=200){http_response_code($code);echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
$pdo=db(); $action=$_GET['action']??'';
if($action==='config'){ out(['ok'=>true,'driver'=>ecommerce_driver(),'mode'=>ecommerce_driver()==='local'?'shared-database':'external-api']); }
if($action==='sync' && $_SERVER['REQUEST_METHOD']==='POST'){
  require_role('merchant');
  $storeId=(int)($_POST['store_id']??0); if(!$storeId) { $b=json_decode(file_get_contents('php://input'),true)??[]; $storeId=(int)($b['store_id']??0); }
  $cat=connector_catalog(); $mapped=[]; $st=$pdo->prepare('INSERT INTO products(store_id,name,price,image,description,stock,external_id,currency) VALUES(?,?,?,?,?,?,?,?)');
  foreach($cat['products']??[] as $p){$m=connector_product_map($p); if(!$m['external_id']) continue; $q=$pdo->prepare('SELECT id FROM products WHERE external_id=?');$q->execute([$m['external_id']]);$id=$q->fetchColumn(); if($id){$u=$pdo->prepare('UPDATE products SET store_id=?,name=?,price=?,image=?,description=?,stock=? WHERE id=?');$u->execute([$storeId,$m['name'],$m['price'],$m['image'],$m['description'],$m['stock'],$id]);} else {$st->execute([$storeId,$m['name'],$m['price'],$m['image'],$m['description'],$m['stock'],$m['external_id'],'USD']);} $mapped[]=$m['name'];}
  out(['ok'=>true,'driver'=>$cat['driver'],'synced'=>count($mapped),'products'=>$mapped]);
}
if($action==='wishlist' && $_SERVER['REQUEST_METHOD']==='POST'){
 $u=current_user(); if(!$u) out(['ok'=>false,'error'=>'Login required'],401); $b=json_decode(file_get_contents('php://input'),true)??[]; $pid=(int)($b['product_id']??0); if(!$pid) out(['ok'=>false,'error'=>'Product required'],422);
 $q=$pdo->prepare('SELECT 1 FROM wishlists WHERE user_id=? AND product_id=?');$q->execute([$u['id'],$pid]); if($q->fetchColumn()){$pdo->prepare('DELETE FROM wishlists WHERE user_id=? AND product_id=?')->execute([$u['id'],$pid]);$added=false;}else{$pdo->prepare('INSERT INTO wishlists(user_id,product_id) VALUES(?,?)')->execute([$u['id'],$pid]);$added=true;} out(['ok'=>true,'added'=>$added]);
}
if($action==='order' && $_SERVER['REQUEST_METHOD']==='POST'){
 $u=current_user(); if(!$u) out(['ok'=>false,'error'=>'Login required'],401); $b=json_decode(file_get_contents('php://input'),true)??[]; $oid=(int)($b['order_id']??0); $q=$pdo->prepare('SELECT * FROM orders WHERE id=? AND user_id=?');$q->execute([$oid,$u['id']]);$o=$q->fetch(); if(!$o) out(['ok'=>false,'error'=>'Order not found'],404); out(['ok'=>true,'order'=>$o]);
}
out(['ok'=>false,'error'=>'Unknown ecommerce action'],404);
