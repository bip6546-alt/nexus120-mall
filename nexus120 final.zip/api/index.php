<?php
require_once __DIR__.'/../db.php';
header('Content-Type: application/json; charset=utf-8');
$action=$_GET['action']??''; $pdo=db();
function json_out($x,int $code=200){http_response_code($code);echo json_encode($x,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);exit;}
function body_json(){return json_decode(file_get_contents('php://input'),true)??[];}

function http_form_post(string $url, array $fields): array {
  $ch = curl_init($url);
  curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_POSTFIELDS=>http_build_query($fields), CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>30, CURLOPT_CONNECTTIMEOUT=>10, CURLOPT_HTTPHEADER=>['Content-Type: application/x-www-form-urlencoded']]);
  $body = curl_exec($ch);
  $err = curl_error($ch);
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  if ($body === false) throw new RuntimeException('Payment gateway connection failed: '.$err);
  $json = json_decode($body, true);
  if (!is_array($json)) throw new RuntimeException('Invalid payment gateway response (HTTP '.$code.')');
  return $json;
}
function http_get_json(string $url): array {
  $ch = curl_init($url);
  curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>30, CURLOPT_CONNECTTIMEOUT=>10, CURLOPT_HTTPHEADER=>['Accept: application/json']]);
  $body = curl_exec($ch); $err=curl_error($ch); $code=curl_getinfo($ch,CURLINFO_HTTP_CODE); curl_close($ch);
  if ($body===false) throw new RuntimeException('Payment gateway connection failed: '.$err);
  $json=json_decode($body,true); if(!is_array($json)) throw new RuntimeException('Invalid gateway response (HTTP '.$code.')'); return $json;
}
function ssl_base(): string { return env_value('SSLCOMMERZ_MODE','sandbox') === 'live' ? 'https://securepay.sslcommerz.com' : 'https://sandbox-gw.sslcommerz.com'; }
function ssl_credentials(): array { $id=env_value('SSLCOMMERZ_STORE_ID',''); $pass=env_value('SSLCOMMERZ_STORE_PASSWORD',''); if(!$id||!$pass) throw new RuntimeException('SSLCOMMERZ credentials are not configured'); return [$id,$pass]; }
function ssl_initiate(PDO $pdo, int $orderId, array $u, float $total, array $shipping): array {
  [$storeId,$storePass]=ssl_credentials();
  $tranId='N120-'.$orderId.'-'.bin2hex(random_bytes(4));
  $base=app_base_url();
  $fields=[
    'store_id'=>$storeId,'store_passwd'=>$storePass,'total_amount'=>number_format($total,2,'.',''),'currency'=>'BDT','tran_id'=>$tranId,
    'success_url'=>$base.'/api/index.php?action=ssl_success','fail_url'=>$base.'/api/index.php?action=ssl_fail','cancel_url'=>$base.'/api/index.php?action=ssl_cancel','ipn_url'=>$base.'/api/index.php?action=ssl_ipn',
    'cus_name'=>$shipping['name']??$u['name'],'cus_email'=>$u['email'],'cus_add1'=>$shipping['address']??'','cus_city'=>$shipping['city']??'Dhaka','cus_state'=>$shipping['state']??'Dhaka','cus_postcode'=>$shipping['postcode']??'','cus_country'=>'Bangladesh','cus_phone'=>$shipping['phone']??'',
    'shipping_method'=>'YES','ship_name'=>$shipping['name']??$u['name'],'ship_add1'=>$shipping['address']??'','ship_city'=>$shipping['city']??'Dhaka','ship_state'=>$shipping['state']??'Dhaka','ship_postcode'=>$shipping['postcode']??'','ship_country'=>'Bangladesh',
    'product_name'=>'NEXUS-120 order #'.$orderId,'product_category'=>'general','product_profile'=>'general'
  ];
  $resp=http_form_post(ssl_base().'/gwprocess/v4/api.php',$fields);
  if(($resp['status']??'')!=='SUCCESS' || empty($resp['GatewayPageURL'])) throw new RuntimeException($resp['failedreason']??'Unable to initialize SSLCOMMERZ payment');
  $pdo->prepare('UPDATE orders SET provider=?,external_order_id=?,payment_session=?,payment_status=? WHERE id=?')->execute(['sslcommerz',$tranId,$resp['sessionkey']??null,'initiated',$orderId]);
  return ['checkout_url'=>$resp['GatewayPageURL'],'tran_id'=>$tranId,'sessionkey'=>$resp['sessionkey']??null];
}
function ssl_validate(array $payload): array {
  [$storeId,$storePass]=ssl_credentials();
  $valId=trim((string)($payload['val_id']??'')); if(!$valId) throw new RuntimeException('Missing validation id');
  $url=ssl_base().'/validator/api/validationserverAPI.php?'.http_build_query(['val_id'=>$valId,'store_id'=>$storeId,'store_passwd'=>$storePass,'v'=>1,'format'=>'json']);
  return http_get_json($url);
}
function complete_ssl_order(PDO $pdo, array $payload, bool $redirect=false): array {
  $tranId=trim((string)($payload['tran_id']??'')); if(!$tranId) throw new RuntimeException('Missing transaction id');
  $st=$pdo->prepare('SELECT * FROM orders WHERE external_order_id=? LIMIT 1'); $st->execute([$tranId]); $order=$st->fetch(); if(!$order) throw new RuntimeException('Order not found');
  $validation=ssl_validate($payload);
  $validStatus=in_array(($validation['status']??''),['VALID','VALIDATED'],true);
  $amountOk=abs((float)($validation['amount']??-1)-(float)$order['total'])<0.01;
  $currencyOk=strtoupper((string)($validation['currency']??'BDT'))==='BDT';
  $tranOk=(string)($validation['tran_id']??'')===$tranId;
  $valid=$validStatus && $amountOk && $currencyOk && $tranOk;
  $pdo->beginTransaction();
  try {
    if($valid) {
      $pdo->prepare("UPDATE orders SET status='processing',payment_status='paid',payment_validation=? WHERE id=?")->execute([json_encode($validation),$order['id']]);
    } else {
      $pdo->prepare("UPDATE orders SET status='payment_failed',payment_status='failed',payment_validation=? WHERE id=?")->execute([json_encode($validation),$order['id']]);
      if((int)$order['stock_reserved']===1){
        $items=$pdo->prepare('SELECT product_id,qty FROM order_items WHERE order_id=?');$items->execute([$order['id']]);$up=$pdo->prepare('UPDATE products SET stock=stock+? WHERE id=?');foreach($items as $it)$up->execute([$it['qty'],$it['product_id']]);
        $pdo->prepare('UPDATE orders SET stock_reserved=0 WHERE id=?')->execute([$order['id']]);
      }
    }
    $pdo->commit();
  } catch(Throwable $e){$pdo->rollBack();throw $e;}
  return ['valid'=>$valid,'order_id'=>(int)$order['id'],'status'=>$valid?'processing':'payment_failed'];
}
function payment_redirect(string $type, int $orderId, string $message=''): never {
  $base=app_base_url();
  $client=trim((string)env_value('CLIENT_RETURN_URL',''));
  if($client){
    $sep=str_contains($client,'?')?'&':'?';
    $query='payment='.rawurlencode($type).'&order='.(int)$orderId;
    if($message) $query.='&message='.rawurlencode($message);
    header('Location: '.$client.$sep.$query); exit;
  }
  $path=$type==='success'?'/payment/success.php':($type==='cancel'?'/payment/cancel.php':'/payment/fail.php');
  header('Location: '.$base.$path.'?order='.$orderId.($message?'&message='.rawurlencode($message):'')); exit;
}
if($action==='bootstrap'){
  $floors=range(1,120);
  $stores=$pdo->query('SELECT s.*,ss.logo,ss.banner,ss.theme_json FROM stores s LEFT JOIN store_settings ss ON ss.store_id=s.id ORDER BY s.floor,s.id')->fetchAll();
  $products=$pdo->query('SELECT p.*,s.name store_name,s.floor,s.category,s.color FROM products p JOIN stores s ON s.id=p.store_id ORDER BY p.id')->fetchAll();
  $mannequins=$pdo->query('SELECT m.*,s.name store_name,s.floor,p.name product_name,p.image product_image,p.auto3d_url,p.clothing_type,p.is_3d_ready,p.clothing_meta FROM mannequins m JOIN stores s ON s.id=m.store_id LEFT JOIN products p ON p.id=m.product_id WHERE m.visible=1 ORDER BY s.floor,m.id')->fetchAll();
  foreach($products as &$p3){$p3['clothing_meta']=json_decode($p3['clothing_meta']??'{}',true)?:[];} unset($p3);
  foreach($stores as &$s){$s['theme']=json_decode($s['theme_json']??'{}',true)?:[];unset($s['theme_json']);} unset($s);
  json_out(['ok'=>true,'user'=>current_user(),'floors'=>$floors,'stores'=>$stores,'products'=>$products,'mannequins'=>$mannequins]);
}
if($action==='register' && $_SERVER['REQUEST_METHOD']==='POST'){
  $b=body_json();$name=trim($b['name']??'');$email=strtolower(trim($b['email']??''));$pass=$b['password']??'';
  if(!$name||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($pass)<6) json_out(['ok'=>false,'error'=>'Name, valid email and 6+ character password required'],422);
  try{$st=$pdo->prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)');$st->execute([$name,$email,password_hash($pass,PASSWORD_DEFAULT)]);$id=$pdo->lastInsertId();$_SESSION['user']=['id'=>(int)$id,'name'=>$name,'email'=>$email,'role'=>'customer'];json_out(['ok'=>true,'user'=>$_SESSION['user']]);}catch(Throwable $e){json_out(['ok'=>false,'error'=>'Email already exists'],409);}
}
if($action==='login' && $_SERVER['REQUEST_METHOD']==='POST'){
  $b=body_json();$email=strtolower(trim($b['email']??''));$pass=$b['password']??'';$st=$pdo->prepare('SELECT id,name,email,password_hash,role FROM users WHERE email=?');$st->execute([$email]);$u=$st->fetch();
  if(!$u||!password_verify($pass,$u['password_hash'])) json_out(['ok'=>false,'error'=>'Invalid credentials'],401);unset($u['password_hash']);$_SESSION['user']=$u;json_out(['ok'=>true,'user'=>$u]);
}
if($action==='logout'){session_destroy();json_out(['ok'=>true]);}
if($action==='wishlist'){
  $u=current_user();if(!$u)json_out(['ok'=>false,'error'=>'Login required'],401);
  if($_SERVER['REQUEST_METHOD']==='POST'){ $b=body_json();$pid=(int)($b['product_id']??0);$pdo->prepare('INSERT OR IGNORE INTO wishlists(user_id,product_id) VALUES(?,?)')->execute([$u['id'],$pid]);json_out(['ok'=>true]); }
  $st=$pdo->prepare('SELECT p.*,s.name store_name FROM wishlists w JOIN products p ON p.id=w.product_id JOIN stores s ON s.id=p.store_id WHERE w.user_id=? ORDER BY w.created_at DESC');$st->execute([$u['id']]);json_out(['ok'=>true,'products'=>$st->fetchAll()]);
}
if($action==='orders'){
  $u=current_user();if(!$u)json_out(['ok'=>false,'error'=>'Login required'],401);
  $st=$pdo->prepare('SELECT o.*,u.name user_name FROM orders o LEFT JOIN users u ON u.id=o.user_id WHERE o.user_id=? ORDER BY o.id DESC');$st->execute([$u['id']]);$orders=$st->fetchAll();
  foreach($orders as &$o){$q=$pdo->prepare('SELECT oi.*,p.name,p.image FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?');$q->execute([$o['id']]);$o['items']=$q->fetchAll();$o['shipping']=json_decode($o['shipping_json']??'{}',true)?:[];}unset($o);json_out(['ok'=>true,'orders'=>$orders]);
}
if($action==='order'){
  $u=current_user();if(!$u)json_out(['ok'=>false,'error'=>'Login required'],401);$id=(int)($_GET['id']??0);$st=$pdo->prepare('SELECT o.*,u.name user_name FROM orders o LEFT JOIN users u ON u.id=o.user_id WHERE o.id=? AND o.user_id=?');$st->execute([$id,$u['id']]);$o=$st->fetch();if(!$o)json_out(['ok'=>false,'error'=>'Order not found'],404);$q=$pdo->prepare('SELECT oi.*,p.name,p.image FROM order_items oi JOIN products p ON p.id=oi.product_id WHERE oi.order_id=?');$q->execute([$id]);$o['items']=$q->fetchAll();$o['shipping']=json_decode($o['shipping_json']??'{}',true)?:[];json_out(['ok'=>true,'order'=>$o]);
}
if($action==='products'){json_out(['ok'=>true,'products'=>$pdo->query('SELECT p.*,s.name store_name,s.floor,s.category,s.color,s.avatar_gender,s.avatar_name FROM products p JOIN stores s ON s.id=p.store_id ORDER BY p.id')->fetchAll()]);}
if($action==='presence' && $_SERVER['REQUEST_METHOD']==='POST'){
  $b=body_json();$sid=session_id();$u=current_user();$st=$pdo->prepare('INSERT INTO presence(session_id,user_id,avatar,floor,x,z,updated_at) VALUES(?,?,?,?,?,?,?) ON CONFLICT(session_id) DO UPDATE SET user_id=excluded.user_id,avatar=excluded.avatar,floor=excluded.floor,x=excluded.x,z=excluded.z,updated_at=excluded.updated_at');$st->execute([$sid,$u['id']??null,$b['avatar']??'cyan',$b['floor']??1,$b['x']??0,$b['z']??0,time()]);json_out(['ok'=>true]);
}
if($action==='users'){$pdo->exec('DELETE FROM presence WHERE updated_at < '.(time()-15));json_out(['ok'=>true,'users'=>$pdo->query('SELECT session_id,user_id,avatar,floor,x,z FROM presence')->fetchAll()]);}
if($action==='store_settings'){
  $storeId=(int)($_GET['store_id']??0);$st=$pdo->prepare('SELECT s.*,ss.logo,ss.banner,ss.theme_json FROM stores s LEFT JOIN store_settings ss ON ss.store_id=s.id WHERE s.id=?');$st->execute([$storeId]);$s=$st->fetch();if(!$s)json_out(['ok'=>false,'error'=>'Store not found'],404);$s['theme']=json_decode($s['theme_json']??'{}',true)?:[];unset($s['theme_json']);json_out(['ok'=>true,'store'=>$s]);
}
if($action==='merchant_product' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user();if(!$u||!in_array($u['role'],['merchant','admin']))json_out(['ok'=>false,'error'=>'Forbidden'],403);$b=body_json();$id=(int)($b['id']??0);$store=(int)($b['store_id']??0);if(!$store||!trim($b['name']??''))json_out(['ok'=>false,'error'=>'Store and product name required'],422);if(!owned_store($pdo,$store,$u))json_out(['ok'=>false,'error'=>'You do not own this store'],403);
  if($id){$check=$pdo->prepare('SELECT id FROM products WHERE id=? AND store_id=?');$check->execute([$id,$store]);if(!$check->fetch())json_out(['ok'=>false,'error'=>'Product not found'],404);$st=$pdo->prepare('UPDATE products SET name=?,price=?,image=?,description=?,stock=?,external_url=?,clothing_type=?,auto3d_url=?,is_3d_ready=?,clothing_meta=? WHERE id=?');$st->execute([trim($b['name']),max(0,(float)$b['price']),trim($b['image']??''),trim($b['description']??''),max(0,(int)$b['stock']),trim($b['external_url']??''),trim($b['clothing_type']??'top'),trim($b['auto3d_url']??''),!empty($b['is_3d_ready'])?1:0,json_encode($b['clothing_meta']??[],JSON_UNESCAPED_SLASHES),$id]);}
  else{$st=$pdo->prepare('INSERT INTO products(store_id,name,price,image,description,stock,external_url,clothing_type,auto3d_url,is_3d_ready,clothing_meta) VALUES(?,?,?,?,?,?,?,?,?,?,?)');$st->execute([$store,trim($b['name']),max(0,(float)$b['price']),trim($b['image']??''),trim($b['description']??''),max(0,(int)$b['stock']),trim($b['external_url']??''),trim($b['clothing_type']??'top'),trim($b['auto3d_url']??''),!empty($b['is_3d_ready'])?1:0,json_encode($b['clothing_meta']??[],JSON_UNESCAPED_SLASHES)]);$id=$pdo->lastInsertId();}
  json_out(['ok'=>true,'id'=>(int)$id]);
}
if($action==='merchant_product_delete' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user(); if(!$u||!in_array($u['role'],['merchant','admin'])) json_out(['ok'=>false,'error'=>'Forbidden'],403);
  $b=body_json(); $id=(int)($b['id']??0); if(!$id) json_out(['ok'=>false,'error'=>'Product id required'],422);
  $q=$pdo->prepare('SELECT p.id,p.store_id FROM products p JOIN stores s ON s.id=p.store_id WHERE p.id=?'); $q->execute([$id]); $p=$q->fetch();
  if(!$p || !owned_store($pdo,(int)$p['store_id'],$u)) json_out(['ok'=>false,'error'=>'Product access denied'],403);
  $pdo->prepare('DELETE FROM products WHERE id=?')->execute([$id]); json_out(['ok'=>true,'deleted_id'=>$id]);
}
if($action==='mannequins'){
  $storeId=(int)($_GET['store_id']??0); $sql='SELECT m.*,p.name product_name,p.image product_image,p.auto3d_url,p.clothing_type,p.is_3d_ready,p.clothing_meta FROM mannequins m LEFT JOIN products p ON p.id=m.product_id';
  if($storeId){$st=$pdo->prepare($sql.' WHERE m.store_id=? ORDER BY m.id');$st->execute([$storeId]);$rows=$st->fetchAll();}else{$rows=$pdo->query($sql.' ORDER BY m.store_id,m.id')->fetchAll();}
  foreach($rows as &$m){$m['clothing_meta']=json_decode($m['clothing_meta']??'{}',true)?:[];} unset($m); json_out(['ok'=>true,'mannequins'=>$rows]);
}
if($action==='merchant_mannequin' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user(); if(!$u||!in_array($u['role'],['merchant','admin'],true)) json_out(['ok'=>false,'error'=>'Forbidden'],403); $b=body_json();
  $id=(int)($b['id']??0); $store=(int)($b['store_id']??0); if(!$store||!owned_store($pdo,$store,$u)) json_out(['ok'=>false,'error'=>'Store access denied'],403);
  $pid=!empty($b['product_id'])?(int)$b['product_id']:null; if($pid){$q=$pdo->prepare('SELECT id FROM products WHERE id=? AND store_id=?');$q->execute([$pid,$store]);if(!$q->fetch())json_out(['ok'=>false,'error'=>'Product does not belong to this store'],422);}
  $vals=[trim($b['name']??'Ghost Mannequin'),(float)($b['x']??0),(float)($b['y']??0),(float)($b['z']??0),(float)($b['rot_x']??0),(float)($b['rot_y']??0),(float)($b['rot_z']??0),max(.2,min(3,(float)($b['scale']??1))),$pid,!empty($b['visible'])?1:0];
  if($id){$q=$pdo->prepare('SELECT id FROM mannequins WHERE id=? AND store_id=?');$q->execute([$id,$store]);if(!$q->fetch())json_out(['ok'=>false,'error'=>'Mannequin not found'],404);$st=$pdo->prepare('UPDATE mannequins SET name=?,x=?,y=?,z=?,rot_x=?,rot_y=?,rot_z=?,scale=?,product_id=?,visible=? WHERE id=?');$st->execute([...$vals,$id]);}
  else{$st=$pdo->prepare('INSERT INTO mannequins(store_id,name,x,y,z,rot_x,rot_y,rot_z,scale,product_id,visible) VALUES(?,?,?,?,?,?,?,?,?,?,?)');$st->execute([$store,...$vals]);$id=$pdo->lastInsertId();}
  json_out(['ok'=>true,'id'=>(int)$id]);
}
if($action==='merchant_mannequin_delete' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user(); if(!$u||!in_array($u['role'],['merchant','admin'],true)) json_out(['ok'=>false,'error'=>'Forbidden'],403);$b=body_json();$id=(int)($b['id']??0);$q=$pdo->prepare('SELECT m.store_id FROM mannequins m WHERE m.id=?');$q->execute([$id]);$m=$q->fetch();if(!$m||!owned_store($pdo,(int)$m['store_id'],$u))json_out(['ok'=>false,'error'=>'Access denied'],403);$pdo->prepare('DELETE FROM mannequins WHERE id=?')->execute([$id]);json_out(['ok'=>true]);
}
if($action==='merchant_product_upload' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user(); if(!$u||!in_array($u['role'],['merchant','admin'],true))json_out(['ok'=>false,'error'=>'Forbidden'],403);$store=(int)($_POST['store_id']??0);if(!$store||!owned_store($pdo,$store,$u))json_out(['ok'=>false,'error'=>'Store access denied'],403);if(empty($_FILES['image'])||$_FILES['image']['error']!==UPLOAD_ERR_OK)json_out(['ok'=>false,'error'=>'2D clothing image is required'],422);
  $f=$_FILES['image'];$allowed=['image/png'=>'png','image/jpeg'=>'jpg','image/webp'=>'webp'];$mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);if(!isset($allowed[$mime]))json_out(['ok'=>false,'error'=>'Use PNG, JPG or WEBP'],422);if($f['size']>8*1024*1024)json_out(['ok'=>false,'error'=>'Image must be 8MB or smaller'],422);
  $dir=__DIR__.'/../assets/uploads/clothing';if(!is_dir($dir))mkdir($dir,0777,true);$name='clothing_'.bin2hex(random_bytes(8)).'.'.$allowed[$mime];if(!move_uploaded_file($f['tmp_name'],$dir.'/'.$name))json_out(['ok'=>false,'error'=>'Upload failed'],500);$url='assets/uploads/clothing/'.$name;
  $pid=(int)($_POST['product_id']??0);$ptype=trim($_POST['clothing_type']??'top');$meta=['source'=>'2d-upload','generator'=>'NEXUS-120 procedural 3D garment shell','generated_at'=>date('c'),'depth'=>0.12,'preset'=>$ptype];
  if($pid){$q=$pdo->prepare('SELECT id FROM products WHERE id=? AND store_id=?');$q->execute([$pid,$store]);if(!$q->fetch())json_out(['ok'=>false,'error'=>'Product not found'],404);$st=$pdo->prepare('UPDATE products SET image=?,clothing_type=?,auto3d_url=?,is_3d_ready=1,clothing_meta=? WHERE id=?');$st->execute([$url,$ptype,$url,json_encode($meta),$pid]);}
  else{$st=$pdo->prepare('INSERT INTO products(store_id,name,price,image,description,stock,currency,sample,clothing_type,auto3d_url,is_3d_ready,clothing_meta) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)');$st->execute([$store,trim($_POST['name']??'New Clothing'),(float)($_POST['price']??0),$url,trim($_POST['description']??'Auto-generated 3D clothing preview'),(int)($_POST['stock']??20),'BDT',0,$ptype,$url,1,json_encode($meta)]);$pid=$pdo->lastInsertId();}
  json_out(['ok'=>true,'product_id'=>(int)$pid,'image'=>$url,'auto3d_url'=>$url,'message'=>'2D image uploaded and 3D garment shell is ready']);
}
if($action==='merchant_order_status' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user();if(!$u||!in_array($u['role'],['merchant','admin']))json_out(['ok'=>false,'error'=>'Forbidden'],403);$b=body_json();$oid=(int)($b['order_id']??0);$status=$b['status']??'';$allowed=['processing','confirmed','shipped','out_for_delivery','delivered'];if(!in_array($status,$allowed,true))json_out(['ok'=>false,'error'=>'Invalid status'],422);$q=$pdo->prepare("SELECT o.id FROM orders o JOIN order_items oi ON oi.order_id=o.id JOIN products p ON p.id=oi.product_id JOIN stores s ON s.id=p.store_id WHERE o.id=? AND (s.owner_id=? OR ?='admin') LIMIT 1");$q->execute([$oid,$u['id'],$u['role']]);if(!$q->fetch())json_out(['ok'=>false,'error'=>'Order access denied'],403);$pdo->prepare('UPDATE orders SET status=? WHERE id=?')->execute([$status,$oid]);json_out(['ok'=>true,'order_id'=>$oid,'status'=>$status]);
}
if($action==='merchant_store' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user();if(!$u||!in_array($u['role'],['merchant','admin']))json_out(['ok'=>false,'error'=>'Forbidden'],403);$b=body_json();$id=(int)($b['store_id']??0);if(!$id||!owned_store($pdo,$id,$u))json_out(['ok'=>false,'error'=>'Store access denied'],403);
  $theme=is_array($b['theme']??null)?$b['theme']:[];$logo=trim($b['logo']??'');$banner=trim($b['banner']??'');$pdo->prepare('INSERT INTO store_settings(store_id,logo,banner,theme_json) VALUES(?,?,?,?) ON CONFLICT(store_id) DO UPDATE SET logo=excluded.logo,banner=excluded.banner,theme_json=excluded.theme_json')->execute([$id,$logo,$banner,json_encode($theme)]);
  $name=trim($b['name']??'');$description=trim($b['description']??'');$color=trim($b['color']??'');if($name)$pdo->prepare('UPDATE stores SET name=?,description=?,color=? WHERE id=?')->execute([$name,$description,$color?:'#00d9ff',$id]);json_out(['ok'=>true]);
}
if($action==='merchant' || $action==='admin'){
  $u=current_user();if(!$u||($action==='merchant'&&!in_array($u['role'],['merchant','admin']))||($action==='admin'&&$u['role']!=='admin'))json_out(['ok'=>false,'error'=>'Forbidden'],403);
  $where=$action==='merchant'?' WHERE s.owner_id='.(int)$u['id']:'';$stats=['users'=>(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),'stores'=>(int)$pdo->query('SELECT COUNT(*) FROM stores'.$where)->fetchColumn(),'products'=>(int)$pdo->query('SELECT COUNT(*) FROM products p JOIN stores s ON s.id=p.store_id'.$where)->fetchColumn(),'orders'=>(int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),'revenue'=>(float)$pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status IN ('paid','processing','shipped','delivered')")->fetchColumn()];
  $stores=$pdo->query('SELECT s.*,COUNT(p.id) products,ss.logo,ss.banner,ss.theme_json FROM stores s LEFT JOIN products p ON p.store_id=s.id LEFT JOIN store_settings ss ON ss.store_id=s.id'.($action==='merchant'?' WHERE s.owner_id='.(int)$u['id']:'').' GROUP BY s.id ORDER BY s.floor')->fetchAll();foreach($stores as &$s){$s['theme']=json_decode($s['theme_json']??'{}',true)?:[];unset($s['theme_json']);}unset($s);
  $recent=$pdo->query('SELECT o.*,u.name user_name FROM orders o LEFT JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 20')->fetchAll();json_out(['ok'=>true,'stats'=>$stats,'stores'=>$stores,'recent_orders'=>$recent]);
}
if($action==='webrtc_token'){
  $u=current_user();
  $role=($u&&($u['role']??'customer')==='admin')?'admin':'customer';
  $secret=(string)env_value('WEBRTC_SECRET','nexus120-dev-webrtc-secret-change-me');
  $payload=['uid'=>(int)($u['id']??0),'role'=>$role,'name'=>(string)($u['name']??'Guest'),'exp'=>time()+300];
  $raw=rtrim(strtr(base64_encode(json_encode($payload,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)),'+/','-_'),'=');
  $sig=rtrim(strtr(base64_encode(hash_hmac('sha256',$raw,$secret,true)),'+/','-_'),'=');
  $ws=(string)env_value('WEBRTC_PUBLIC_URL','');
  if(!$ws){
    $https=!empty($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off';
    $host=$_SERVER['HTTP_HOST']??'localhost';
    $host=preg_replace('/:\d+$/','',$host);
    $ws=($https?'wss://':'ws://').$host.':2567/ws';
  }
  json_out(['ok'=>true,'token'=>$raw.'.'.$sig,'ws_url'=>$ws,'role'=>$role,'expires_at'=>$payload['exp']]);
}
if($action==='mall_broadcasts'){
  $limit=min(30,max(1,(int)($_GET['limit']??12)));
  $since=max(0,(int)($_GET['since']??0));
  $q=$pdo->prepare("SELECT b.*,u.name user_name FROM mall_broadcasts b LEFT JOIN users u ON u.id=b.user_id WHERE b.id>? ORDER BY b.id ASC LIMIT $limit");
  $q->execute([$since]);
  json_out(['ok'=>true,'broadcasts'=>$q->fetchAll()]);
}
if($action==='admin_broadcast' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user(); if(!$u||$u['role']!=='admin') json_out(['ok'=>false,'error'=>'Admin access required'],403);
  $b=body_json(); $message=trim((string)($b['message']??'')); $billboard=trim((string)($b['billboard_message']??$message));
  $type=in_array(($b['type']??'announcement'),['announcement','security','emergency','info'],true)?$b['type']:'announcement';
  $severity=in_array(($b['severity']??'info'),['info','warning','critical'],true)?$b['severity']:'info';
  $floor=(int)($b['floor']??0); if(!$message) json_out(['ok'=>false,'error'=>'Announcement message is required'],422);
  $st=$pdo->prepare('INSERT INTO mall_broadcasts(user_id,type,message,billboard_message,floor,severity) VALUES(?,?,?,?,?,?)');
  $st->execute([$u['id'],$type,$message,$billboard?:$message,$floor>0?$floor:null,$severity]);
  json_out(['ok'=>true,'broadcast_id'=>(int)$pdo->lastInsertId()]);
}
if($action==='admin_security' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user(); if(!$u||$u['role']!=='admin') json_out(['ok'=>false,'error'=>'Admin access required'],403);
  $b=body_json(); $floor=max(1,min(120,(int)($b['floor']??1))); $type=trim((string)($b['alert_type']??'Security patrol')); $message=trim((string)($b['message']??'Security team dispatched to Floor '.$floor));
  if(!$type||!$message) json_out(['ok'=>false,'error'=>'Security type and message are required'],422);
  $pdo->beginTransaction();
  try{
    $st=$pdo->prepare("INSERT INTO security_alerts(user_id,floor,alert_type,message,status) VALUES(?,?,?,?, 'active')"); $st->execute([$u['id'],$floor,$type,$message]); $aid=(int)$pdo->lastInsertId();
    $bb=$pdo->prepare('INSERT INTO mall_broadcasts(user_id,type,message,billboard_message,floor,severity) VALUES(?,?,?,?,?,?)');
    $bb->execute([$u['id'],'security',$message,'SECURITY · FLOOR '.$floor.' · '.$type.' — '.$message,$floor,'warning']);
    $pdo->commit(); json_out(['ok'=>true,'alert_id'=>$aid]);
  }catch(Throwable $e){$pdo->rollBack();json_out(['ok'=>false,'error'=>$e->getMessage()],500);}
}
if($action==='admin_security_resolve' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user(); if(!$u||$u['role']!=='admin') json_out(['ok'=>false,'error'=>'Admin access required'],403);
  $b=body_json(); $id=(int)($b['id']??0); if(!$id) json_out(['ok'=>false,'error'=>'Alert id required'],422);
  $pdo->prepare("UPDATE security_alerts SET status='resolved',resolved_at=CURRENT_TIMESTAMP WHERE id=?")->execute([$id]);
  json_out(['ok'=>true,'alert_id'=>$id]);
}
if($action==='admin_control_room'){
  $u=current_user(); if(!$u||$u['role']!=='admin') json_out(['ok'=>false,'error'=>'Admin access required'],403);
  $stats=[
    'users'=>(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(),
    'stores'=>(int)$pdo->query('SELECT COUNT(*) FROM stores')->fetchColumn(),
    'products'=>(int)$pdo->query('SELECT COUNT(*) FROM products')->fetchColumn(),
    'orders'=>(int)$pdo->query('SELECT COUNT(*) FROM orders')->fetchColumn(),
    'revenue'=>(float)$pdo->query("SELECT COALESCE(SUM(total),0) FROM orders WHERE status IN ('paid','processing','shipped','delivered')")->fetchColumn(),
    'online'=>(int)$pdo->query('SELECT COUNT(*) FROM presence WHERE updated_at >= '.(time()-15))->fetchColumn(),
    'active_security'=>(int)$pdo->query("SELECT COUNT(*) FROM security_alerts WHERE status='active'")->fetchColumn()
  ];
  $stores=$pdo->query('SELECT s.id,s.floor,s.name,s.category,s.owner_id,s.avatar_name,COUNT(p.id) products FROM stores s LEFT JOIN products p ON p.store_id=s.id GROUP BY s.id ORDER BY s.floor')->fetchAll();
  $broadcasts=$pdo->query('SELECT b.*,u.name user_name FROM mall_broadcasts b LEFT JOIN users u ON u.id=b.user_id ORDER BY b.id DESC LIMIT 30')->fetchAll();
  $alerts=$pdo->query('SELECT a.*,u.name user_name FROM security_alerts a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.id DESC LIMIT 30')->fetchAll();
  json_out(['ok'=>true,'stats'=>$stats,'stores'=>$stores,'broadcasts'=>$broadcasts,'alerts'=>$alerts]);
}
if($action==='checkout' && $_SERVER['REQUEST_METHOD']==='POST'){
  $u=current_user();if(!$u)json_out(['ok'=>false,'error'=>'Login required'],401);$b=body_json();$items=$b['items']??[];$shipping=is_array($b['shipping']??null)?$b['shipping']:[];$payment=$shipping['payment']??'sslcommerz';if(!$items)json_out(['ok'=>false,'error'=>'Cart is empty'],422);
  $pdo->beginTransaction();
  try {
    $total=0;$rows=[];$q=$pdo->prepare('SELECT id,price,stock,currency FROM products WHERE id=?');
    foreach($items as $it){$q->execute([(int)$it['id']]);$p=$q->fetch();$qty=max(1,(int)$it['qty']);if(!$p||$p['stock']<$qty)throw new Exception('Product unavailable or out of stock');$total+=(float)$p['price']*$qty;$rows[]=[$p['id'],$qty,$p['price']];}
    $currency='BDT';
    $st=$pdo->prepare('INSERT INTO orders(user_id,total,status,provider,payment_status,shipping_json,stock_reserved) VALUES(?,?,?,?,?,?,?)');
    $provider=$payment==='cod'?'cod':'sslcommerz';$st->execute([$u['id'],$total,$payment==='cod'?'processing':'pending_payment',$provider,$payment==='cod'?'unpaid':'unpaid',json_encode($shipping),1]);$oid=(int)$pdo->lastInsertId();
    $oi=$pdo->prepare('INSERT INTO order_items(order_id,product_id,qty,price) VALUES(?,?,?,?)');$up=$pdo->prepare('UPDATE products SET stock=stock-? WHERE id=?');
    foreach($rows as $r){$oi->execute([$oid,$r[0],$r[1],$r[2]]);$up->execute([$r[1],$r[0]]);}
    $pdo->commit();
    if($payment==='cod') json_out(['ok'=>true,'order_id'=>$oid,'total'=>$total,'status'=>'processing','payment_status'=>'unpaid']);
    $paymentInfo=ssl_initiate($pdo,$oid,$u,$total,$shipping);
    json_out(['ok'=>true,'order_id'=>$oid,'total'=>$total,'status'=>'pending_payment','payment_status'=>'initiated','redirect_url'=>$paymentInfo['checkout_url'],'provider'=>'sslcommerz']);
  } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();json_out(['ok'=>false,'error'=>$e->getMessage()],422);}
}

if(in_array($action,['ssl_success','ssl_fail','ssl_cancel','ssl_ipn'],true)){
  try {
    $payload=array_merge($_GET,$_POST);
    if($action==='ssl_ipn'){ $result=complete_ssl_order($pdo,$payload); json_out(['ok'=>$result['valid'],'order_id'=>$result['order_id'],'status'=>$result['status']]); }
    $result=complete_ssl_order($pdo,$payload,false);
    payment_redirect($result['valid']?'success':'fail',$result['order_id']);
  } catch(Throwable $e) {
    if($action==='ssl_ipn') json_out(['ok'=>false,'error'=>$e->getMessage()],422);
    $order=(int)($_POST['value_a']??$_GET['order']??0); if($order>0) payment_redirect($action==='ssl_cancel'?'cancel':'fail',$order,$e->getMessage());
    http_response_code(400); echo 'Payment callback error: '.htmlspecialchars($e->getMessage()); exit;
  }
}
json_out(['ok'=>false,'error'=>'Unknown action'],404);
