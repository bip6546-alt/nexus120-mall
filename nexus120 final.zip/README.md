# NEXUS-120 — Cinematic 3D Commerce Demo

This build adds a 100-store sample mall, merchant-editable sample catalogs, store sales avatars, floor billboards, and a 3-second post-purchase cinematic.

## New demo features

- 100 sample 3D stores across floors 1–100
- Every store starts with 5 sample products
- Merchant can edit or delete sample products from the Merchant 3D Shop Editor
- Every store has a stylized male or female sales-host avatar
- 4 rotating/advertising billboard panels are generated on the active floor
- Customer product selection still highlights the exact 3D product on the shelf
- Product → Cart → Checkout → SSLCOMMERZ/COD flow remains intact
- After a successful order, a 3-second cinematic plays:
  - purchase complete overlay
  - customer avatar moves through a short celebration beat
  - NEXUS-120 shopping bag appears on the avatar
  - shopping bag remains attached to the customer after the cinematic
- Mobile-friendly customer UI and cinematic presentation are retained

## Demo accounts

Merchant:
- Email: `merchant@nexus120.local`
- Password: `Merchant@12345`

Admin:
- Email: `admin@nexus120.local`
- Password: `Admin@12345`

## XAMPP

Copy the project into:

`C:\xampp\htdocs\nexus120_cinematic_work2`

Open:

`http://localhost/nexus120_cinematic_work2/client/`

Merchant editor:

`http://localhost/nexus120_cinematic_work2/merchant/`

The SQLite database is created automatically under `data/nexus120.sqlite` on first PHP request.

## Notes

The 100 stores and their sample catalogs are seeded automatically. Once a store is marked as seeded, deleting a sample product will not cause it to be recreated on the next request.

The 3-second purchase cinematic is a local visual effect. Real payment confirmation still depends on the configured payment gateway callback/IPN.


## Ambient Entertainment Music
- Includes an original, locally generated 24-second ambient background loop (`assets/nexus-ambient.wav`).
- Every customer/browser has an independent Music On/Off preference stored in `localStorage`.
- Music starts only after the customer presses the on-screen Music button, respecting browser autoplay policies.
- Playback is intentionally very quiet and designed as background ambience.
- No paid music library or external audio service is required.

## Administrator Control Room + Live Mall Mic
- Admin URL: `http://localhost/nexus120_cinematic_work2/admin/`
- Demo admin: `admin@nexus120.local` / `Admin@12345`
- Admin can start a browser microphone and turn every final recognized command into a public mall announcement.
- Public announcements are stored server-side, polled by all mall clients, shown as a HUD announcement, spoken with browser Speech Synthesis when enabled, and mirrored onto the 3D public advertising billboard.
- Customers can independently enable/disable `Public Voice` in the mall HUD.
- Admin can also type billboard/public messages and publish them to all floors.
- Security command center supports floor-based security dispatch, alert types, active/resolved alerts, and public security announcements.
- The admin control room includes live online count, users, stores, products, orders, revenue, security status, public command history, and the 100-store directory.
- Browser microphone support depends on the browser's Web Speech API (`SpeechRecognition` / `webkitSpeechRecognition`).
- This implementation broadcasts the recognized command as text + synthesized public voice; it is not raw microphone audio streaming. Raw live audio to every customer would require a WebRTC/Node real-time media layer.


## WebRTC Live Mall Audio

The Administrator Control Room now has a **Live Audio Server**. The admin grants microphone access, Node.js authenticates a short-lived WebRTC token and provides signaling over `ws://...:2567/ws`, and browsers exchange WebRTC audio directly. Customers can enable **Live Mall Audio** from the mall HUD.

### Local run
1. Start PHP/Apache and the Node realtime server on port `2567`.
2. Ensure the same `WEBRTC_SECRET` is configured in the PHP root `.env` and `server/.env` (or the Docker Compose environment).
3. Open the mall at `http://localhost:8080/` and the admin panel at `/admin/`.
4. Admin clicks **Start / Stop Live Audio** and allows microphone access.
5. Customers click **Live Mall Audio** once to satisfy browser autoplay permission.

### Important architecture note
This implementation uses **Node.js WebSocket signaling + WebRTC peer-to-peer audio fan-out**. The Node server does not decode or store microphone audio. For very large audiences, an SFU such as mediasoup/Janus should replace the peer fan-out so the administrator uploads one stream instead of one WebRTC stream per listener.

## Customer proximity social chat
- Customer avatars exchange live positions through the Node realtime server.
- Default proximity radius is **0.10 metres** (`PROXIMITY_METERS=0.10`).
- Customers inside the radius see each other as 3D avatars and receive nearby controls for **SMS chat** and **WebRTC voice chat**.
- SMS is server-routed only when the two customers are still inside the configured radius.
- Voice requires the customer to explicitly allow microphone access; the microphone is never enabled automatically.
- For production, use HTTPS/WSS and set a strong `WEBRTC_SECRET`.

## Ghost Mannequin + 2D → 3D Clothing System

- Fashion stores automatically receive a visible ghost mannequin.
- Merchants can create multiple mannequins per store and edit X/Y/Z position, X/Y/Z rotation, scale and visibility.
- Each mannequin can be linked to a clothing product.
- Merchant Studio includes a live Three.js mannequin preview.
- Merchants can upload PNG/JPG/WEBP clothing images.
- The upload flow marks the product as 3D-ready and stores procedural garment metadata.
- Customer 3D mall wraps the 2D clothing texture onto a procedural 3D garment shell (top/dress/pants/skirt) and places it on the saved mannequin position.
- This is a local/browser-friendly procedural 2D-to-3D display system; it does not require an external AI API or paid 3D-generation service.
- For production photorealistic mesh generation, the stored clothing metadata can later be connected to a dedicated 2D-to-3D/GLB generation provider.

## Customer Shopping Groups
- Customers within the configured 0.10 m proximity can create a Shopping Group and invite nearby customers.
- Group size defaults to 8 and is controlled by `MAX_GROUP_SIZE`.
- Members see live group membership/floor, can use Group SMS chat, and can enable Group Voice.
- Group membership is real-time/session based; leaving or disconnecting updates the group automatically.

## Free / Open Asset Library
- Added `merchant/assets.php` as a merchant-facing asset source and license reference panel.
- Added `assets/library/free-assets.json` with source/license metadata.
- Preferred external source: Poly Haven CC0 for 3D models, HDRIs and textures.
- Heroicons is listed for MIT-licensed UI SVG icons.
- Unsplash and Pexels are listed for 2D photography, with a reminder to review individual image/third-party rights.
- NEXUS-120's own SVG logo, mall hero, shop hero and product-card assets remain local originals.
