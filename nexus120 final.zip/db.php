<?php
require_once __DIR__.'/config/config.php';
function db(): PDO {
  static $pdo;
  if ($pdo) return $pdo;
  if (!is_dir(dirname(DB_FILE))) mkdir(dirname(DB_FILE), 0777, true);
  $pdo = new PDO('sqlite:'.DB_FILE, null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
  $pdo->exec('PRAGMA foreign_keys=ON');
  init_db($pdo);
  return $pdo;
}
function init_db(PDO $pdo): void {
  $pdo->exec("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'customer', created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS stores (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, floor INTEGER NOT NULL, category TEXT, color TEXT DEFAULT '#00d9ff', description TEXT, owner_id INTEGER, avatar_gender TEXT DEFAULT 'female', avatar_name TEXT DEFAULT 'Store Host', catalog_seeded INTEGER DEFAULT 0, FOREIGN KEY(owner_id) REFERENCES users(id) ON DELETE SET NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL, name TEXT NOT NULL, price REAL NOT NULL, image TEXT, description TEXT, stock INTEGER DEFAULT 100, external_id TEXT, external_url TEXT, currency TEXT DEFAULT 'USD', sample INTEGER DEFAULT 1, FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, total REAL NOT NULL, status TEXT DEFAULT 'paid', provider TEXT, external_order_id TEXT, tracking_url TEXT, shipping_json TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER NOT NULL, qty INTEGER NOT NULL, price REAL NOT NULL, FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES products(id))");
  $pdo->exec("CREATE TABLE IF NOT EXISTS wishlists (user_id INTEGER NOT NULL, product_id INTEGER NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(user_id,product_id), FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS store_settings (store_id INTEGER PRIMARY KEY, logo TEXT, banner TEXT, theme_json TEXT, FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS mannequins (id INTEGER PRIMARY KEY AUTOINCREMENT, store_id INTEGER NOT NULL, name TEXT NOT NULL DEFAULT 'Ghost Mannequin', x REAL DEFAULT 0, y REAL DEFAULT 0, z REAL DEFAULT 0, rot_x REAL DEFAULT 0, rot_y REAL DEFAULT 0, rot_z REAL DEFAULT 0, scale REAL DEFAULT 1, product_id INTEGER, visible INTEGER DEFAULT 1, FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE, FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE SET NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS presence (session_id TEXT PRIMARY KEY, user_id INTEGER, avatar TEXT, floor INTEGER DEFAULT 1, x REAL DEFAULT 0, z REAL DEFAULT 0, updated_at INTEGER NOT NULL, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS mall_broadcasts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, type TEXT NOT NULL DEFAULT 'announcement', message TEXT NOT NULL, billboard_message TEXT, floor INTEGER, severity TEXT NOT NULL DEFAULT 'info', created_at TEXT DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
  $pdo->exec("CREATE TABLE IF NOT EXISTS security_alerts (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER, floor INTEGER NOT NULL, alert_type TEXT NOT NULL, message TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'active', created_at TEXT DEFAULT CURRENT_TIMESTAMP, resolved_at TEXT, FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE SET NULL)");
  foreach ([['products','external_id','TEXT'],['products','external_url','TEXT'],['products','currency',"TEXT DEFAULT 'USD'"],['products','sample',"INTEGER DEFAULT 1"],['orders','provider','TEXT'],['orders','external_order_id','TEXT'],['orders','tracking_url','TEXT'],['orders','shipping_json','TEXT'],['orders','payment_status',"TEXT DEFAULT 'unpaid'"],['orders','payment_session','TEXT'],['orders','payment_validation','TEXT'],['orders','stock_reserved',"INTEGER DEFAULT 0"],['stores','avatar_gender',"TEXT DEFAULT 'female'"],['stores','avatar_name',"TEXT DEFAULT 'Store Host'"],['stores','catalog_seeded',"INTEGER DEFAULT 0"],['products','clothing_type',"TEXT DEFAULT 'top'"],['products','auto3d_url','TEXT'],['products','is_3d_ready','INTEGER DEFAULT 0'],['products','clothing_meta','TEXT']] as $m) { try { $pdo->exec("ALTER TABLE {$m[0]} ADD COLUMN {$m[1]} {$m[2]}"); } catch(Throwable $e) {} }
  $count=(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
  if ($count===0) {
    $stmt=$pdo->prepare('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)');
    $stmt->execute(['Admin','admin@nexus120.local',password_hash('Admin@12345',PASSWORD_DEFAULT),'admin']);
    $stmt->execute(['Demo Merchant','merchant@nexus120.local',password_hash('Merchant@12345',PASSWORD_DEFAULT),'merchant']);
  }
  ensure_sample_catalog($pdo);
}
function ensure_sample_catalog(PDO $pdo): void {
  $merchant=(int)$pdo->query("SELECT id FROM users WHERE role='merchant' ORDER BY id LIMIT 1")->fetchColumn();
  $pal=['#ff3ea5','#00d9ff','#a78bfa','#f472b6','#22c55e','#f59e0b','#60a5fa','#34d399','#f97316','#06b6d4','#c084fc','#f43f5e'];
  $cats=[['Fashion',['Jacket','Sneakers','T-Shirt','Backpack','Cap']],['Electronics',['Earbuds','Smartphone','Tablet','Keyboard','Gamepad']],['Home',['Lamp','Sofa','Chair','Desk','Mirror']],['Beauty',['Serum','Makeup Set','Cleanser','Perfume','Hair Kit']],['Gaming',['Gaming Keyboard','Controller','Headset','Mouse','Console Stand']],['Grocery',['Bento Box','Coffee','Snack Box','Juice','Organic Basket']],['Books',['Future Cities','Novel','Design Guide','Kids Book','Business Book']],['Sports',['Training Bag','Running Shoes','Yoga Mat','Bottle','Fitness Watch']],['Kids',['Robo Builder Kit','Puzzle','Toy Car','STEM Kit','Plush Toy']],['Optics',['Prism Glasses','Sunglasses','Blue Light Glasses','Travel Case','Lens Kit']],['Art',['Creator Art Kit','Sketch Set','Paint Set','Canvas','Marker Pack']],['Gifts',['Collector Box','Gift Set','Photo Frame','Travel Mug','Premium Card']]];
  $existing=(int)$pdo->query('SELECT COUNT(*) FROM stores')->fetchColumn();
  if($existing<100){
    $ins=$pdo->prepare('INSERT INTO stores(name,floor,category,color,description,owner_id,avatar_gender,avatar_name) VALUES(?,?,?,?,?,?,?,?)');
    for($i=$existing+1;$i<=100;$i++){
      $cat=$cats[($i-1)%count($cats)]; $color=$pal[($i-1)%count($pal)]; $gender=$i%2?'female':'male';
      $ins->execute([sprintf('%02d · %s Store',$i,$cat[0]),$i,$cat[0],$color,'Sample merchant storefront with editable products',$merchant,$gender,$gender==='female'?'Maya':'Arif']);
    }
  }
  // Normalize host avatars for the original 12 stores too.
  $allStores=$pdo->query('SELECT id FROM stores ORDER BY id')->fetchAll();
  $upHost=$pdo->prepare('UPDATE stores SET avatar_gender=?, avatar_name=? WHERE id=?');
  foreach($allStores as $idx=>$st){ $gender=(($idx+1)%2)?'female':'male'; $upHost->execute([$gender,$gender==='female'?'Maya':'Arif',(int)$st['id']]); }
  $pdo->exec("UPDATE stores SET catalog_seeded=1 WHERE catalog_seeded=0 AND id IN (SELECT DISTINCT store_id FROM products)");
  // Fill missing sample products so every store starts with a sellable mini catalog.
  $productCount=$pdo->prepare('SELECT COUNT(*) FROM products WHERE store_id=?');
  $markSeed=$pdo->prepare('UPDATE stores SET catalog_seeded=1 WHERE id=?');
  $stores=$pdo->query('SELECT id, name, category, color, catalog_seeded FROM stores ORDER BY id')->fetchAll();
  $insP=$pdo->prepare('INSERT INTO products(store_id,name,price,image,description,stock,currency,sample) VALUES(?,?,?,?,?,?,?,1)');
  foreach($stores as $st){
    $productCount->execute([$st['id']]); $n=(int)$productCount->fetchColumn(); if((int)$st['catalog_seeded']===1) continue; if($n>0){$markSeed->execute([$st['id']]); continue;}
    $cat=($cats[array_search($st['category'],array_column($cats,0))] ?? $cats[0]);
    $base=['🛍️','✨','📦','⭐','🎁'];
    for($j=$n;$j<5;$j++){
      $name=$cat[1][$j%count($cat[1])].' '.$st['id']; $price=round(19+($st['id']*7)+$j*13.5,2);
      $insP->execute([$st['id'],$name,$price,$base[$j%5],'Sample product — merchant can edit or delete it',20+($j*10),'BDT']);
    }
    $markSeed->execute([$st['id']]);
  }
  // Every Fashion store gets a default ghost mannequin. Merchants can add/edit/delete more from the 3D editor.
  $fashionStores=$pdo->query("SELECT id FROM stores WHERE lower(category)='fashion' ORDER BY id")->fetchAll();
  $hasMan=$pdo->prepare('SELECT COUNT(*) FROM mannequins WHERE store_id=?');
  $firstProduct=$pdo->prepare('SELECT id FROM products WHERE store_id=? ORDER BY id LIMIT 1');
  $addMan=$pdo->prepare("INSERT INTO mannequins(store_id,name,x,y,z,rot_x,rot_y,rot_z,scale,product_id,visible) VALUES(?,?,?,?,?,?,?,?,?,?,1)");
  foreach($fashionStores as $fs){ $hasMan->execute([(int)$fs['id']]); if((int)$hasMan->fetchColumn()===0){ $firstProduct->execute([(int)$fs['id']]); $pid=$firstProduct->fetchColumn(); $addMan->execute([(int)$fs['id'],'Ghost Mannequin',0,0,0,0,0,0,1,$pid ? $pid : null]); } }
  // Mark Fashion catalog items as 3D-ready so the mall can render clothing on the mannequin immediately.
  $fashionProducts=$pdo->query("SELECT p.id,p.name FROM products p JOIN stores s ON s.id=p.store_id WHERE lower(s.category)='fashion'")->fetchAll();
  $up3d=$pdo->prepare('UPDATE products SET clothing_type=?,is_3d_ready=1,clothing_meta=? WHERE id=?');
  foreach($fashionProducts as $fp){$n=strtolower($fp['name']);$type=str_contains($n,'dress')?'dress':(str_contains($n,'pants')?'pants':(str_contains($n,'skirt')?'skirt':'top'));$up3d->execute([$type,json_encode(['generator'=>'NEXUS-120 procedural 3D garment shell','preset'=>$type],JSON_UNESCAPED_SLASHES),(int)$fp['id']]);}
}
function current_user(): ?array { return $_SESSION['user'] ?? null; }
function require_role(string $role): void { $u=current_user(); if(!$u || ($role!=='admin' && $u['role']!==$role && $u['role']!=='admin')) { http_response_code(403); exit('Forbidden'); } }
function owned_store(PDO $pdo, int $storeId, array $u): ?array { $st=$pdo->prepare("SELECT * FROM stores WHERE id=? AND (owner_id=? OR ?='admin')"); $st->execute([$storeId,(int)$u['id'],$u['role']]); return $st->fetch() ?: null; }
