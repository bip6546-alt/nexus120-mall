import * as THREE from "three";
import { Client } from "@colyseus/sdk";

const API="/api/index.php";
const ASSET="/assets/";
const scene=new THREE.Scene(); scene.background=new THREE.Color(0x030711); scene.fog=new THREE.FogExp2(0x050916,.012);
const camera=new THREE.PerspectiveCamera(70,innerWidth/innerHeight,.1,500);
const renderer=new THREE.WebGLRenderer({antialias:true});renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setSize(innerWidth,innerHeight);document.body.appendChild(renderer.domElement);
scene.add(new THREE.HemisphereLight(0x9edfff,0x102030,2.2));const sun=new THREE.DirectionalLight(0xffffff,2.2);sun.position.set(10,22,10);scene.add(sun);
const floorMesh=new THREE.Mesh(new THREE.PlaneGeometry(100,100),new THREE.MeshStandardMaterial({color:0x10202b,roughness:.82}));floorMesh.rotation.x=-Math.PI/2;scene.add(floorMesh);
const avatar=new THREE.Mesh(new THREE.CapsuleGeometry(.45,1.1,4,8),new THREE.MeshStandardMaterial({color:0x1bd9ff}));avatar.position.set(0,1,18);scene.add(avatar);
const raycaster=new THREE.Raycaster(),mouse=new THREE.Vector2();const keys={};let yaw=0,pitch=0,locked=false,room=null,currentFloor=1;
let data={stores:[],products:[]};let cart=JSON.parse(sessionStorage.getItem("nexus_cart")||"[]");
let checkoutShipping={};let selectedPayment="sslcommerz";let lastOrderId=null;
let selectedProductMesh=null;
let selectedProductPulse=0;
let shoppingBag=null;
let salesHosts=[];
let billboards=[];
let purchaseCinematicRunning=false;
const $=s=>document.querySelector(s), esc=s=>String(s??"").replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function saveCart(){sessionStorage.setItem("nexus_cart",JSON.stringify(cart));updateCartCount()}
function updateCartCount(){$("#cartCount").textContent=cart.reduce((a,x)=>a+x.qty,0)}
function money(p){return `${p.currency||'BDT'} ${Number(p.price).toFixed(2)}`}
function productIcon(p){const n=String(p.name||'').toLowerCase();let src='';if(n.includes('air max')||n.includes('shoe'))src=ASSET+'product-card.svg';else if(n.includes('t-shirt')||n.includes('shirt'))src=ASSET+'shop-hero.svg';if(p.image&&/^https?:\/\//.test(p.image))src=p.image;return src?`<img src="${esc(src)}" alt="${esc(p.name)}">`:`<span>${esc(p.image||'🛍️')}</span>`}
function openModal(id){$("#"+id).classList.remove("hidden");document.body.classList.add("modal-open")}
function closeModal(id){$("#"+id).classList.add("hidden");if(id==="productModal")clearProductHighlight();if(!document.querySelector(".modal:not(.hidden)"))document.body.classList.remove("modal-open")}
document.addEventListener("click",e=>{const c=e.target.closest("[data-close]");if(c)closeModal(c.dataset.close)});

function clearProductHighlight(){
  if(!selectedProductMesh) return;
  const m=selectedProductMesh;
  if(m.userData.highlightRing){m.remove(m.userData.highlightRing);m.userData.highlightRing.geometry.dispose();m.userData.highlightRing.material.dispose();m.userData.highlightRing=null;}
  if(m.userData.highlightLight){m.remove(m.userData.highlightLight);m.userData.highlightLight.dispose?.();m.userData.highlightLight=null;}
  if(m.userData.originalEmissive){m.material.emissive.copy(m.userData.originalEmissive);}
  selectedProductMesh=null;
}
function highlightProductMesh(p){
  clearProductHighlight();
  const hits=[];
  mallGroup.traverse(o=>{if(o.isMesh&&o.userData.product&&Number(o.userData.product.id)===Number(p.id))hits.push(o);});
  const m=hits[0];
  if(!m) return;
  selectedProductMesh=m;
  m.userData.originalEmissive=m.material.emissive.clone();
  const accent=new THREE.Color(m.userData.product.store_color||'#66e8ff');
  m.material.emissive.copy(accent).multiplyScalar(.8);
  const ring=new THREE.Mesh(new THREE.TorusGeometry(.95,.055,12,48),new THREE.MeshBasicMaterial({color:accent,transparent:true,opacity:.95}));
  ring.rotation.x=Math.PI/2;
  ring.position.y=-.72;
  m.add(ring);
  m.userData.highlightRing=ring;
  const light=new THREE.PointLight(accent,2.2,4.5);
  light.position.set(0,.2,0);
  m.add(light);
  m.userData.highlightLight=light;
  selectedProductPulse=0;
}
function showProduct(p){
  highlightProductMesh(p);
  const related=data.products.filter(x=>Number(x.store_id)===Number(p.store_id)).slice(0,4);
  $("#productBody").innerHTML=`<div class="selected-product"><div class="product-image">${productIcon(p)}</div><div class="product-info"><div class="store-chip">${esc(p.store_name||'NEXUS-120 Store')} · Floor ${esc(p.floor||currentFloor)}</div><h2>${esc(p.name)}</h2><p class="description">${esc(p.description||'Premium product from the NEXUS-120 merchant store.')}</p><div class="price">${money(p)}</div><div class="product-highlight-note">● <strong>Selected in 3D shop</strong> — the physical product is highlighted on its shelf</div><p class="stock ${Number(p.stock)>0?'':'out'}">${Number(p.stock)>0?`● In stock · ${p.stock} available`:'● Out of stock'}</p><div class="actions"><button class="primary" id="addProduct" ${p.stock<1?'disabled':''}>🛒 Add to Cart</button><button id="buyNow" ${p.stock<1?'disabled':''}>⚡ Buy Now</button><button id="wishProduct">♡ Wishlist</button></div></div></div><div class="selected-products-strip"><b>More from this shop</b><div>${related.map(r=>`<button class="mini-product" data-related="${r.id}">${productIcon(r)}<span>${esc(r.name)}</span><b>${money(r)}</b></button>`).join('')}</div></div>`;
  const add=()=>{const x=cart.find(i=>i.id===p.id);if(x)x.qty=Math.min(x.qty+1,Number(p.stock));else cart.push({id:p.id,name:p.name,price:Number(p.price),image:p.image,qty:1,stock:Number(p.stock),currency:p.currency||'BDT',store_name:p.store_name});saveCart();toast(`${p.name} added to cart`)};
  $("#addProduct")?.addEventListener("click",()=>{add();closeModal("productModal");openCart()});
  $("#buyNow")?.addEventListener("click",()=>{add();closeModal("productModal");openCart();setTimeout(()=>openCheckout(),50)});
  $("#wishProduct")?.addEventListener("click",async()=>{try{const r=await fetch(`${API}?action=wishlist`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({product_id:p.id})});const d=await r.json();toast(d.ok?'Added to wishlist':(d.error||'Wishlist unavailable'))}catch(e){toast('Wishlist request failed')}});
  $("#productBody").querySelectorAll("[data-related]").forEach(b=>b.addEventListener('click',()=>showProduct(data.products.find(x=>Number(x.id)===Number(b.dataset.related))||p)));
  openModal("productModal");
}
function cartTotal(){return cart.reduce((a,x)=>a+x.price*x.qty,0)}
function xCurrency(n){return `${cart[0]?.currency||'BDT'} ${Number(n).toFixed(2)}`}
function cartSummary(){return `<div class="summary-line"><span>${cart.reduce((a,x)=>a+x.qty,0)} items</span><strong>${xCurrency(cartTotal())}</strong></div>`}
function openCart(){
  if(!cart.length){$("#cartBody").innerHTML='<div class="empty">Your cart is empty. Click a 3D product to add it.</div>';openModal("cartModal");return}
  $("#cartBody").innerHTML=cart.map((x,i)=>`<div class="cart-row"><div class="thumb">${productIcon(x)}</div><div><b>${esc(x.name)}</b><div class="muted">${esc(x.store_name||'NEXUS Store')}</div><div>${money(x)}</div></div><div class="qty"><button data-minus="${i}">−</button><span>${x.qty}</span><button data-plus="${i}">+</button></div><button class="icon-btn" data-remove="${i}">✕</button></div>`).join('')+`<div class="cart-footer"><div class="total"><span>Order total</span><span>${xCurrency(cartTotal())}</span></div><button class="primary full" id="checkoutBtn">Proceed to Checkout →</button></div>`;
  $("#cartBody").querySelectorAll("[data-minus]").forEach(b=>b.onclick=()=>changeQty(+b.dataset.minus,-1));
  $("#cartBody").querySelectorAll("[data-plus]").forEach(b=>b.onclick=()=>changeQty(+b.dataset.plus,1));
  $("#cartBody").querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart.splice(+b.dataset.remove,1);saveCart();openCart()});
  $("#checkoutBtn").onclick=()=>{closeModal("cartModal");openCheckout()};
  openModal("cartModal");
}
function changeQty(i,d){cart[i].qty=Math.max(0,Math.min(cart[i].stock,cart[i].qty+d));if(!cart[i].qty)cart.splice(i,1);saveCart();openCart()}
function openCheckout(){
  if(!cart.length){openCart();return}
  $("#checkoutSummary").innerHTML=`<div class="summary-card">${cart.slice(0,4).map(x=>`<div><span>${productIcon(x)} ${esc(x.name)} × ${x.qty}</span><b>${xCurrency(x.price*x.qty)}</b></div>`).join('')}${cart.length>4?`<div class="muted">+ ${cart.length-4} more items</div>`:''}<hr><div><strong>Total</strong><strong>${xCurrency(cartTotal())}</strong></div></div>`;
  $("#checkoutForm").reset();
  Object.entries(checkoutShipping).forEach(([k,v])=>{const el=$("#checkoutForm [name='"+k+"']");if(el)el.value=v});
  openModal("checkoutModal");
}
$("#checkoutForm").onsubmit=e=>{e.preventDefault();checkoutShipping=Object.fromEntries(new FormData(e.target).entries());closeModal("checkoutModal");openPayment()};
function openPayment(){
  $("#paymentSummary").innerHTML=`<div class="summary-card compact"><div><span>Products</span><strong>${cart.reduce((a,x)=>a+x.qty,0)} items</strong></div><div><span>Delivery to</span><strong>${esc(checkoutShipping.city||'Bangladesh')}</strong></div><div class="grand"><span>Total</span><strong>${xCurrency(cartTotal())}</strong></div></div>`;
  selectedPayment='sslcommerz';document.querySelectorAll('.pay-option').forEach(b=>{b.classList.toggle('selected',b.dataset.payment===selectedPayment);b.lastElementChild.textContent=b.dataset.payment===selectedPayment?'✓':'○'});updatePaymentButton();openModal("paymentModal")
}
function updatePaymentButton(){const b=$("#payNowBtn");b.textContent=selectedPayment==='sslcommerz'?'Pay securely with SSLCOMMERZ →':'Place Cash-on-Delivery Order →';$("#paymentNote").textContent=selectedPayment==='sslcommerz'?'You will be redirected to SSLCOMMERZ secure hosted checkout.':'No online payment is taken. Pay the delivery agent when the order arrives.'}
document.querySelectorAll('.pay-option').forEach(b=>b.addEventListener('click',()=>{selectedPayment=b.dataset.payment;document.querySelectorAll('.pay-option').forEach(x=>{x.classList.toggle('selected',x===b);x.lastElementChild.textContent=x===b?'✓':'○'});updatePaymentButton()}));
$("#payNowBtn").onclick=async()=>{
  if(!cart.length)return;
  const b=$("#payNowBtn");b.disabled=true;b.textContent='Creating order…';
  try{
    const r=await fetch(`${API}?action=checkout`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({items:cart.map(x=>({id:x.id,qty:x.qty})),shipping:{...checkoutShipping,payment:selectedPayment}})});
    const d=await r.json();if(!d.ok)throw new Error(d.error||'Checkout failed');
    lastOrderId=d.order_id;
    const purchasedItems=cart.map(x=>({...x}));
    if(selectedPayment==='sslcommerz'&&d.redirect_url){window.location.href=d.redirect_url;return}
    cart=[];saveCart();closeModal('paymentModal'); await playPurchaseCinematic(purchasedItems); showSuccess(d.order_id,d.total,'Cash on Delivery',purchasedItems);
  }catch(e){toast(e.message||'Payment request failed')}finally{b.disabled=false;updatePaymentButton()}
};
function showSuccess(orderId,total,payment='SSLCOMMERZ',items=[]){
  lastOrderId=orderId; const list=items.length?items:cart;
  const currency=list[0]?.currency||'BDT';
  $("#successBody").innerHTML=`<div class="success-order"><div class="success-order-id">Order #${orderId}</div><div class="success-items">${list.length?list.map(x=>`<div>${productIcon(x)}<span>${esc(x.name)} × ${x.qty}</span><b>${currency} ${Number(x.price*x.qty).toFixed(2)}</b></div>`).join(''):'<div class="muted">Your order has been received.</div>'}</div><div class="success-total"><span>Paid / payable</span><strong>${currency} ${Number(total).toFixed(2)}</strong></div><div class="payment-badge">✓ ${esc(payment)} · Order processing</div></div>`;
  $("#successOrderBtn").onclick=()=>{closeModal('successModal');openOrders()};openModal('successModal');
}
function renderOrders(orders){if(!orders.length){$("#ordersBody").innerHTML='<div class="empty">No orders yet.</div>';return}$("#ordersBody").innerHTML=orders.map(o=>{const steps=['processing','confirmed','shipped','out_for_delivery','delivered'];const status=steps.indexOf(o.status);return `<div class="order"><div class="order-head"><b>Order #${o.id}</b><span>${esc(o.status)}</span></div><div class="muted">${esc(o.created_at||'')}</div><div class="order-items">${(o.items||[]).map(i=>`<div>${esc(i.name)} × ${i.qty}</div>`).join('')}</div><div class="track">${steps.map((s,i)=>`<span class="step ${i<=status?'active':''}">${s.replaceAll('_',' ')}</span>`).join('')}</div>${o.tracking_url?`<p><a href="${esc(o.tracking_url)}" target="_blank" rel="noopener">Track shipment</a></p>`:''}<strong>Total: ${Number(o.total).toFixed(2)}</strong></div>`}).join('')}
async function openOrders(){const r=await fetch(`${API}?action=orders`);const d=await r.json();if(!d.ok){toast(d.error||'Login required');return}renderOrders(d.orders);openModal("ordersModal")}
$("#cartBtn").onclick=openCart;$("#ordersBtn").onclick=openOrders;
$("#successModal").addEventListener('click',e=>{if(e.target.id==='successModal')closeModal('successModal')});
function toast(msg){let t=document.querySelector('.toast');if(!t){t=document.createElement('div');t.className='toast';document.body.appendChild(t)}t.textContent=msg;t.classList.add('show');clearTimeout(t._timer);t._timer=setTimeout(()=>t.classList.remove('show'),2200)}

async function bootstrap(){
  const r=await fetch(`${API}?action=bootstrap`); const d=await r.json(); if(!d.ok) throw new Error(d.error||'Unable to load mall'); data=d; setupFloors(); rebuildFloor(); updateCartCount();
}
function setupFloors(){const s=$("#floor");s.innerHTML=data.floors.map(f=>`<option value="${f}">Floor ${f}</option>`).join('');s.value=currentFloor;s.onchange=()=>changeFloor(Number(s.value));}
function clearGroup(g){while(g.children.length)g.remove(g.children[0])}
const mallGroup=new THREE.Group();scene.add(mallGroup);
function makeTextSprite(text,color){const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d');ctx.fillStyle='#07131c';ctx.fillRect(0,0,c.width,c.height);ctx.strokeStyle=color;ctx.lineWidth=6;ctx.strokeRect(3,3,c.width-6,c.height-6);ctx.fillStyle='#fff';ctx.font='bold 34px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text.slice(0,24),256,64);const tex=new THREE.CanvasTexture(c);const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,transparent:true}));sp.scale.set(6,1.5,1);return sp}
function addCinematicAtrium(){
  const g=new THREE.Group();
  const ringMat=new THREE.MeshBasicMaterial({color:0x7b5cff,transparent:true,opacity:.28});
  [18,28,38].forEach((r,i)=>{const ring=new THREE.Mesh(new THREE.TorusGeometry(r,.06,10,96),ringMat.clone());ring.rotation.x=Math.PI/2;ring.position.y=0.06+i*.015;g.add(ring)});
  for(let i=0;i<12;i++){const a=i*Math.PI/6;const light=new THREE.PointLight(i%2?0x4de8ff:0x8b5cff,2.4,18);light.position.set(Math.cos(a)*25,3,Math.sin(a)*25);g.add(light)}
  const ceiling=new THREE.Mesh(new THREE.CylinderGeometry(10,14,1.2,64,1,true),new THREE.MeshBasicMaterial({color:0x0c1225,side:THREE.BackSide,transparent:true,opacity:.82}));ceiling.position.y=12;g.add(ceiling);
  const core=new THREE.Mesh(new THREE.CylinderGeometry(4.5,4.5,.12,64),new THREE.MeshBasicMaterial({color:0x6e4cff,transparent:true,opacity:.22}));core.position.y=.08;g.add(core);scene.add(g);
}
function addSalesAvatar(g,store){
  const host=new THREE.Group(); host.position.set(0,0,1.25); host.userData.host=true;
  const female=String(store.avatar_gender||'female')==='female';
  const body=new THREE.Mesh(new THREE.CapsuleGeometry(.34,.9,4,10),new THREE.MeshStandardMaterial({color:new THREE.Color(store.color||'#7b5cff'),roughness:.55})); body.position.y=1.05; host.add(body);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.31,20,14),new THREE.MeshStandardMaterial({color:0xf1c7a8,roughness:.8})); head.position.y=1.95; host.add(head);
  if(female){const hair=new THREE.Mesh(new THREE.SphereGeometry(.34,18,12,0,Math.PI*2,0,Math.PI*.62),new THREE.MeshStandardMaterial({color:0x2b1721}));hair.position.y=2.03;host.add(hair)}else{const hair=new THREE.Mesh(new THREE.SphereGeometry(.33,18,12,0,Math.PI*2,0,Math.PI*.45),new THREE.MeshStandardMaterial({color:0x1b1b22}));hair.position.y=2.05;host.add(hair)}
  const armL=new THREE.Mesh(new THREE.CapsuleGeometry(.1,.52,4,8),new THREE.MeshStandardMaterial({color:0xe8bda1}));armL.position.set(-.38,1.12,0);armL.rotation.z=.28;host.add(armL);
  const armR=armL.clone();armR.position.x=.38;armR.rotation.z=-.28;host.add(armR);
  const badge=makeTextSprite(`${store.avatar_name||'Store Host'} · ${female?'Sales Woman':'Sales Man'}`,store.color||'#00d9ff');badge.scale.set(3.2,.65,1);badge.position.set(0,2.65,0);host.add(badge);
  host.userData.baseY=0;host.userData.phase=Math.random()*Math.PI*2;g.add(host);salesHosts.push(host);
}
function makeBillboard(text,color,position,rotationY=0){
  const c=document.createElement('canvas');c.width=900;c.height=300;const ctx=c.getContext('2d');ctx.fillStyle='#050914';ctx.fillRect(0,0,c.width,c.height);ctx.strokeStyle=color;ctx.lineWidth=10;ctx.strokeRect(8,8,c.width-16,c.height-16);ctx.fillStyle='#fff';ctx.font='900 58px Arial';ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('NEXUS-120',450,78);ctx.font='700 34px Arial';ctx.fillStyle=color;ctx.fillText(text.slice(0,34),450,158);ctx.font='600 24px Arial';ctx.fillStyle='#b8c7d3';ctx.fillText('SHOP • DISCOVER • BUY',450,218);const tex=new THREE.CanvasTexture(c);const mesh=new THREE.Mesh(new THREE.PlaneGeometry(7.5,2.5),new THREE.MeshBasicMaterial({map:tex,transparent:true,side:THREE.DoubleSide}));mesh.position.copy(position);mesh.rotation.y=rotationY;mesh.userData.billboard=true;return mesh;
}
function addFloorBillboards(){
  billboards.forEach(b=>{b.parent?.remove(b);b.geometry?.dispose();b.material?.map?.dispose();b.material?.dispose?.()});billboards=[];
  const colors=['#7b5cff','#42e8ff','#ff4ea3','#55efb0'];
  const ads=[`Floor ${currentFloor} · Featured Stores`,`FREE DELIVERY WEEK · SHOP NOW`,`NEW ARRIVALS · NEXUS-120`,`MERCHANT SALE · UP TO 30% OFF`];
  [[-10,3.2,-2,0.18],[10,3.2,-2,-0.18],[-10,7.2,9,0.18],[10,7.2,9,-0.18]].forEach((pos,i)=>{const b=makeBillboard(ads[i],colors[i],new THREE.Vector3(pos[0],pos[1],pos[2]),pos[3]);mallGroup.add(b);billboards.push(b)});
}
function addShop(store,index){
  const g=new THREE.Group(); const x=index%2?18:-18; const z=Math.floor(index/2)*12-8; g.position.set(x,0,z); g.userData.store=store.id;
  const shopLight=new THREE.PointLight(new THREE.Color(store.color||'#6e4cff'),7,20);shopLight.position.set(0,5,1);g.add(shopLight);
  const mat=new THREE.MeshStandardMaterial({color:new THREE.Color(store.theme?.wallColor||store.color||'#18455c'),roughness:.7});const body=new THREE.Mesh(new THREE.BoxGeometry(13,5,8),mat);body.position.y=2.5;g.add(body);
  const open=new THREE.Mesh(new THREE.BoxGeometry(8,4.2,.4),new THREE.MeshStandardMaterial({color:0x07131c,roughness:.4}));open.position.set(0,2.1,4.05);g.add(open);
  const sign=makeTextSprite(store.name,store.color||'#00d9ff');sign.position.set(0,6,4.2);g.add(sign); addSalesAvatar(g,store);
  const prods=data.products.filter(p=>Number(p.store_id)===Number(store.id));
  prods.forEach((p,pi)=>{const shelf=new THREE.Mesh(new THREE.BoxGeometry(2.8,2.2,.7),new THREE.MeshStandardMaterial({color:new THREE.Color(store.theme?.shelfColor||'#2b3d47'),roughness:.8}));shelf.position.set(-4+pi*2,1.3,3.1);g.add(shelf);const productColor=store.color||'#00d9ff';p.store_color=productColor;const pm=new THREE.Mesh(new THREE.BoxGeometry(1.35,1.35,.8),new THREE.MeshStandardMaterial({color:0x142d3b,metalness:.25,roughness:.35,emissive:new THREE.Color(productColor).multiplyScalar(.22)}));pm.position.set(-4+pi*2,2.35,2.65);pm.userData.product=p;pm.userData.shopColor=productColor;g.add(pm);const label=makeTextSprite(`${p.name} · ${Number(p.price).toFixed(0)}`,productColor);label.scale.set(2.2,.65,1);label.position.set(-4+pi*2,3.5,2.7);g.add(label)});
  mallGroup.add(g);
}
function createShoppingBag(){
  if(shoppingBag) return shoppingBag;
  const bag=new THREE.Group(); const body=new THREE.Mesh(new THREE.BoxGeometry(.55,.7,.35),new THREE.MeshStandardMaterial({color:0x7b5cff,roughness:.5,emissive:0x1d0e46}));body.position.y=.25;bag.add(body);const handle=new THREE.Mesh(new THREE.TorusGeometry(.22,.045,10,24,Math.PI),new THREE.MeshBasicMaterial({color:0xddd7ff}));handle.rotation.x=Math.PI;handle.position.y=.62;bag.add(handle);const tag=makeTextSprite('NEXUS-120', '#ffffff');tag.scale.set(1.05,.28,1);tag.position.set(0,.28,.19);bag.add(tag);bag.visible=false;avatar.add(bag);bag.position.set(.68,.05,.15);shoppingBag=bag;return bag;
}
createShoppingBag();
function playPurchaseCinematic(items=[]){
  if(purchaseCinematicRunning) return Promise.resolve(); purchaseCinematicRunning=true; const bag=createShoppingBag(); bag.visible=false;
  const overlay=document.querySelector('#purchaseCinematic'); if(overlay){const name=items[0]?.name||'Your purchase';overlay.querySelector('[data-cine-title]').textContent='PURCHASE COMPLETE';overlay.querySelector('[data-cine-product]').textContent=name;overlay.classList.remove('hidden');overlay.classList.remove('play');void overlay.offsetWidth;overlay.classList.add('play')}
  const start=avatar.position.clone(); const startYaw=yaw; let frame=0; const t0=performance.now();
  return new Promise(resolve=>{const step=(now)=>{const t=Math.min(1,(now-t0)/3000); const eased=t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2; if(t<.42){avatar.position.z=start.z-eased*1.4; yaw=startYaw-.12*eased}else{bag.visible=true;bag.position.y=.05+Math.sin((t-.42)*20)*.025;avatar.position.z=start.z-1.4} if(t>=1){bag.visible=true;purchaseCinematicRunning=false;if(overlay)overlay.classList.add('hidden');resolve();return} frame=requestAnimationFrame(step)};frame=requestAnimationFrame(step)});
}
function rebuildFloor(){clearGroup(mallGroup);salesHosts=[];billboards=[];const stores=data.stores.filter(s=>Number(s.floor)===currentFloor);stores.forEach(addShop);addFloorBillboards();$("#shopLabel").textContent=stores.length?`Floor ${currentFloor} · ${stores.length} interactive 3D shops · Sales host available`:`Floor ${currentFloor} · Lobby / elevator`;avatar.position.set(0,1,18);camera.position.set(avatar.position.x,2.2,avatar.position.z+7)}
function changeFloor(f){currentFloor=Math.max(1,Math.min(120,f));$("#floor").value=currentFloor;rebuildFloor();if(room)room.send('floor',{floor:currentFloor})}
$("#lift").onclick=()=>changeFloor(Number($("#floor").value));
renderer.domElement.addEventListener('click',e=>{mouse.x=(e.clientX/innerWidth)*2-1;mouse.y=-(e.clientY/innerHeight)*2+1;raycaster.setFromCamera(mouse,camera);const hits=raycaster.intersectObjects(mallGroup.children,true);const hit=hits.find(h=>h.object.userData.product);if(hit){showProduct(hit.object.userData.product);return}if(!locked)renderer.domElement.requestPointerLock?.()});
addEventListener('keydown',e=>keys[e.key.toLowerCase()]=true);addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);document.addEventListener('pointerlockchange',()=>locked=document.pointerLockElement===renderer.domElement);document.addEventListener('mousemove',e=>{if(locked){yaw-=e.movementX*.002;pitch=Math.max(-1.2,Math.min(1.2,pitch-e.movementY*.002))}});
async function connect(){try{const client=new Client('ws://localhost:2567');room=await client.joinOrCreate('mall',{floor:1,name:'Guest-'+Math.floor(Math.random()*9999)});$("#status").textContent='LIVE · '+room.sessionId.slice(0,6)}catch(e){$("#status").textContent='LOCAL MODE';console.warn(e)}}
async function presence(){try{await fetch(`${API}?action=presence`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({floor:currentFloor,x:avatar.position.x,z:avatar.position.z,avatar:'cyan'})})}catch(e){}}
async function handlePaymentReturn(){const q=new URLSearchParams(location.search);const status=q.get('payment');const order=q.get('order');if(status==='success'&&order){try{const r=await fetch(`${API}?action=order&id=${encodeURIComponent(order)}`);const d=await r.json();if(d.ok){const o=d.order;const purchasedItems=(o.items||[]).map(x=>({...x,qty:Number(x.qty),price:Number(x.price),currency:'BDT'}));cart=[];saveCart();await playPurchaseCinematic(purchasedItems);showSuccess(o.id,o.total,'SSLCOMMERZ',purchasedItems);}else{const purchasedItems=cart.map(x=>({...x}));cart=[];saveCart();await playPurchaseCinematic(purchasedItems);showSuccess(order,q.get('total')||'0','SSLCOMMERZ',purchasedItems)}}catch(e){showSuccess(order,q.get('total')||'0','SSLCOMMERZ')}history.replaceState({},'',location.pathname)}else if(status==='failed'&&order){toast(`Payment failed for order #${order}`);history.replaceState({},'',location.pathname)}}
function tick(){requestAnimationFrame(tick);
  salesHosts.forEach((h,i)=>{h.position.y=Math.sin(performance.now()*.0015+h.userData.phase)*.025;h.rotation.y=Math.sin(performance.now()*.0007+h.userData.phase)*.08});
  if(selectedProductMesh){selectedProductPulse+=0.08;const ring=selectedProductMesh.userData.highlightRing;if(ring){ring.rotation.z=selectedProductPulse*.7;const pulse=1+Math.sin(selectedProductPulse*2.2)*.12;ring.scale.set(pulse,pulse,pulse);ring.material.opacity=.72+Math.sin(selectedProductPulse*2.2)*.22;}const light=selectedProductMesh.userData.highlightLight;if(light)light.intensity=1.8+Math.sin(selectedProductPulse*2.2)*.5;}const speed=.18;const forward=(keys.w?1:0)-(keys.s?1:0),side=(keys.d?1:0)-(keys.a?1:0);const dir=new THREE.Vector3(side,0,forward);if(dir.lengthSq())dir.normalize().applyAxisAngle(new THREE.Vector3(0,1,0),yaw);avatar.position.addScaledVector(dir,speed);avatar.position.x=Math.max(-45,Math.min(45,avatar.position.x));avatar.position.z=Math.max(-45,Math.min(45,avatar.position.z));camera.position.set(avatar.position.x,avatar.position.y+1.2,avatar.position.z+7);camera.rotation.set(pitch,yaw,0,'YXZ');if(room&&dir.lengthSq())room.send('move',{x:avatar.position.x,z:avatar.position.z,rot:yaw});renderer.render(scene,camera)}
addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight)});
await bootstrap();await connect();setInterval(presence,5000);tick();handlePaymentReturn();
