<?php
const DB_FILE = __DIR__ . '/../data/nexus120.sqlite';
const APP_NAME = 'NEXUS-120 3D Virtual Metamall';
const SESSION_NAME = 'nexus120_session';
if (session_status() === PHP_SESSION_NONE) { session_name(SESSION_NAME); session_start(); }

function env_value(string $key, $default = null) {
  static $loaded = false, $values = [];
  if (!$loaded) {
    $loaded = true;
    $file = __DIR__ . '/../.env';
    if (is_file($file)) {
      foreach (file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        $v = trim($v);
        if ((str_starts_with($v, '"') && str_ends_with($v, '"')) || (str_starts_with($v, "'") && str_ends_with($v, "'"))) $v = substr($v, 1, -1);
        $values[trim($k)] = $v;
      }
    }
  }
  return array_key_exists($key, $values) ? $values[$key] : (getenv($key) !== false ? getenv($key) : $default);
}

function app_base_url(): string {
  $configured = rtrim((string)env_value('APP_BASE_URL', ''), '/');
  if ($configured) return $configured;
  $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
  $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
  $path = rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
  // api/index.php lives one level below the project root.
  if (str_ends_with($path, '/api')) $path = substr($path, 0, -4);
  return $scheme . '://' . $host . $path;
}
