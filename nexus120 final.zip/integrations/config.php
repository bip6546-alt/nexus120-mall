<?php
// Configure ONE ecommerce source in .env or your server environment.
// Supported connectors: local, woocommerce, shopify, magento, rest
function ecommerce_config(): array {
  return [
    'driver' => getenv('ECOMMERCE_DRIVER') ?: 'local',
    'base_url' => rtrim(getenv('ECOMMERCE_BASE_URL') ?: '', '/'),
    'consumer_key' => getenv('ECOMMERCE_CONSUMER_KEY') ?: '',
    'consumer_secret' => getenv('ECOMMERCE_CONSUMER_SECRET') ?: '',
    'access_token' => getenv('ECOMMERCE_ACCESS_TOKEN') ?: '',
    'api_version' => getenv('ECOMMERCE_API_VERSION') ?: '2025-10',
    'timeout' => (int)(getenv('ECOMMERCE_TIMEOUT') ?: 15),
  ];
}
function ecommerce_request(string $method, string $path, ?array $body=null): array {
  $c=ecommerce_config();
  if($c['driver']==='local') return ['status'=>200,'data'=>null];
  $url=$c['base_url'].'/'.$path;
  $headers=['Accept: application/json','Content-Type: application/json'];
  $auth='';
  if($c['driver']==='woocommerce') {
    $sep=str_contains($url,'?')?'&':'?'; $url.=$sep.'consumer_key='.rawurlencode($c['consumer_key']).'&consumer_secret='.rawurlencode($c['consumer_secret']);
  } elseif(in_array($c['driver'],['shopify','rest'],true) && $c['access_token']) {
    $headers[]='Authorization: Bearer '.$c['access_token'];
  } elseif($c['driver']==='magento' && $c['access_token']) {
    $headers[]='Authorization: Bearer '.$c['access_token'];
  }
  $ch=curl_init($url); curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_CUSTOMREQUEST=>$method,CURLOPT_HTTPHEADER=>$headers,CURLOPT_TIMEOUT=>$c['timeout']]);
  if($body!==null) curl_setopt($ch,CURLOPT_POSTFIELDS,json_encode($body));
  $raw=curl_exec($ch); $status=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE); $err=curl_error($ch); curl_close($ch);
  if($err) throw new RuntimeException($err);
  $data=json_decode($raw,true); if($status>=400) throw new RuntimeException('E-commerce API HTTP '.$status.': '.($raw?:'Unknown error'));
  return ['status'=>$status,'data'=>$data];
}
function ecommerce_driver(): string { return ecommerce_config()['driver']; }
