<?php
require_once __DIR__.'/config.php';
function connector_catalog(): array {
  $driver=ecommerce_driver();
  if($driver==='local') return ['driver'=>'local','mode'=>'shared-database','products'=>null];
  if($driver==='woocommerce') {
    $r=ecommerce_request('GET','wp-json/wc/v3/products?per_page=100');
    return ['driver'=>$driver,'mode'=>'external','products'=>$r['data']];
  }
  if($driver==='shopify') {
    $v=ecommerce_config()['api_version'];
    $r=ecommerce_request('GET','admin/api/'.$v.'/products.json?limit=250');
    return ['driver'=>$driver,'mode'=>'external','products'=>$r['data']['products']??[]];
  }
  if($driver==='magento') {
    $r=ecommerce_request('GET','rest/V1/products?searchCriteria[pageSize]=100');
    return ['driver'=>$driver,'mode'=>'external','products'=>$r['data']['items']??[]];
  }
  $r=ecommerce_request('GET','products');
  return ['driver'=>$driver,'mode'=>'external','products'=>$r['data']??[]];
}
function connector_product_map(array $p): array {
  $driver=ecommerce_driver();
  if($driver==='woocommerce') return ['external_id'=>(string)($p['id']??''),'name'=>$p['name']??'Product','price'=>(float)($p['price']??0),'stock'=>(int)($p['stock_quantity']??0),'image'=>$p['images'][0]['src']??'','description'=>strip_tags($p['short_description']??$p['description']??'')];
  if($driver==='shopify') return ['external_id'=>(string)($p['id']??''),'name'=>$p['title']??'Product','price'=>(float)($p['variants'][0]['price']??0),'stock'=>(int)($p['variants'][0]['inventory_quantity']??0),'image'=>$p['image']['src']??'','description'=>strip_tags($p['body_html']??'')];
  if($driver==='magento') return ['external_id'=>(string)($p['id']??$p['sku']??''),'name'=>$p['name']??'Product','price'=>(float)($p['price']??0),'stock'=>(int)($p['extension_attributes']['stock_item']['qty']??0),'image'=>$p['media_gallery_entries'][0]['file']??'','description'=>$p['custom_attributes'][0]['value']??''];
  return ['external_id'=>(string)($p['id']??$p['sku']??''),'name'=>$p['name']??'Product','price'=>(float)($p['price']??0),'stock'=>(int)($p['stock']??$p['inventory']??0),'image'=>$p['image']??'','description'=>$p['description']??''];
}
