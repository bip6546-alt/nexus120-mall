<?php
require_once __DIR__ . '/config.php';
header('Content-Type: application/json; charset=utf-8');
$action=$_GET['action'] ?? 'status';

switch($action){
  case 'status':
    echo json_encode([
      'ok'=>true,
      'service'=>'nexus120-commerce-api',
      'realtime'=>'node-colyseus',
      'presence'=>'redis',
      'floors'=>120
    ]);
    break;
  case 'stores':
    $rows=db()->query("SELECT id,floor,name,category,logo,description FROM stores ORDER BY floor,id")->fetchAll();
    echo json_encode(['ok'=>true,'stores'=>$rows]);
    break;
  case 'products':
    $rows=db()->query("SELECT p.id,p.name,p.category,p.price,p.image,p.stock,s.name store_name,s.floor FROM products p JOIN stores s ON s.id=p.store_id ORDER BY p.id")->fetchAll();
    echo json_encode(['ok'=>true,'products'=>$rows]);
    break;
  default:
    http_response_code(404);
    echo json_encode(['ok'=>false,'error'=>'Unknown action']);
}
